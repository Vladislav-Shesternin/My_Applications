package novibet.leoforos.irakloiu.office.helper.game.utils

const val WIDTH_UI     = 603f
const val HEIGHT_UI    = 1333f

const val TIME_ANIM_SCREEN_ALPHA = 0.333f