package novibet.leoforos.irakloiu.office.helper.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background = Color.valueOf("156162")
    val text       = Color.valueOf("4B959A")

}