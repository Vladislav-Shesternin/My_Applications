package com.bettilt.mobile.pt.game.actors.checkbox

import novibet.leoforos.irakloiu.office.helper.game.actors.checkbox.ACheckBox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}