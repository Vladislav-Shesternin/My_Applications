package com.bettilt.mobile.pt.util.sudaNeXodi_TudaToje

class TrueMethods {
    fun method1(): Boolean {
        return true
    }

    fun method2(): Boolean {
        return 10 in (5..15)
    }

    fun method3(): Boolean {
        return 15 in (5..20)
    }

    fun method4(n: Int): Boolean {
        return (2 + n) == 4
    }

    fun method5(flag: Boolean): Boolean {
        return !flag
    }
}