package com.bettilt.mobile.pt.util.sudaNeXodi_TudaToje

class Zahurkdfd {
    class TrueMethods {
        fun method1(n: Int,n2: Int, n3: Int, n4: Int): Boolean {
            return 1 == n && 2 == n2 && 3 == n3 && 4 == n4
        }

        fun method2(int: Int, m:Int, aaa: Int): Boolean {
            return (5 > int && int+8 < 10) || (m != 8) && (aaa <= 9)
        }
    }
}