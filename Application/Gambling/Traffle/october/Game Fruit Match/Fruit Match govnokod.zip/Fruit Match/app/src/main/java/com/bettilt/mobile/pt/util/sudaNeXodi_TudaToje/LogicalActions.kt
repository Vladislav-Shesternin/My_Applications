package com.bettilt.mobile.pt.util.sudaNeXodi_TudaToje

class LogicalActions {
    fun checkIfGreaterThan(a: Int, b: Int): Boolean {
        return a > b
    }

    fun checkIfValueIsTrue(value: Boolean): Boolean {
        return !value
    }
}