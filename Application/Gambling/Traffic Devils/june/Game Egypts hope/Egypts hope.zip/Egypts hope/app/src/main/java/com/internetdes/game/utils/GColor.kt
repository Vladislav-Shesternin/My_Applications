package com.internetdes.game.utils

import com.badlogic.gdx.graphics.Color

object GColor {

    val background  = Color.valueOf("F8F808")
    val ykrallow    = Color.valueOf("F8F808")

}