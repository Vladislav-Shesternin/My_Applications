package com.amayasoft.cars.kids.toddlers.garage.ga.game.box2d

object BodyId {
    const val NONE = "none"

    const val ITEM = "ITEM"
    const val RULT = "RULT"
}