package com.duckduckmoosedesign.cpk.game.box2d

object BodyId {
    const val NONE = "none"

    const val ITEM = "ITEM"
    const val AVIA = "AVIA"
}