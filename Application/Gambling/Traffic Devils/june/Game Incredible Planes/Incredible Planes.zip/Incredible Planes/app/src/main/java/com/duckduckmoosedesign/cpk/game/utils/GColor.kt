package com.duckduckmoosedesign.cpk.game.utils

import com.badlogic.gdx.graphics.Color

object GColor {

    val background  = Color.valueOf("552FBC")
}