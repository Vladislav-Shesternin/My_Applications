package com.maxgames.stickwarl

data class Luiza(
    val id: Int,
    val name: String,
    val age: Int,
    val isActive: Boolean,
    val salary: Double
)