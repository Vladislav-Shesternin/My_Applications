package com.maxgames.stickwarl

data class Hand(
    val id: Int,
    val name: String,
    val isLeftHanded: Boolean,
    val length: Double,
    val fingers: Int,
    val strength: Float,
    val owner: String
)