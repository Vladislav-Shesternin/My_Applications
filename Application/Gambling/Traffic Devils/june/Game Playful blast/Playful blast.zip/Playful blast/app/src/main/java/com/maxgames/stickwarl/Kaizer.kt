package com.maxgames.stickwarl

data class Kaizer(
    val id: Long,
    val name: String,
    val category: String,
    val price: Double
)