package com.maxgames.stickwarl

data class Side(
    val id: Int,
    val name: String,
    val length: Double,
    val width: Float
)