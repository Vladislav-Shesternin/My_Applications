package com.maxgames.stickwarl

data class Summer(
    val id: Long,
    val cityName: String,
    val temperature: Float,
    val isSunny: Boolean,
    val holiday: String
)