package com.maxgames.stickwarl

data class Antuan(
    val id: Int,
    val name: String,
    val isActive: Boolean,
    val balance: Double,
    val country: String
)