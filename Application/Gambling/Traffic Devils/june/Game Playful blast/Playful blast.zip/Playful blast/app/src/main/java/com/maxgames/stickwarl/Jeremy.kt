package com.maxgames.stickwarl

data class Jeremy(
    val field1: Long,
    val field2: Long,
    val field3: Int,
    val field4: String,
    val field5: Long,
    val field6: Float,
    val field7: Boolean
)