package com.JindoBlu.game.actors.checkbox

import com.maxgames.stickwarl.game.actors.checkbox.ACheckBox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}