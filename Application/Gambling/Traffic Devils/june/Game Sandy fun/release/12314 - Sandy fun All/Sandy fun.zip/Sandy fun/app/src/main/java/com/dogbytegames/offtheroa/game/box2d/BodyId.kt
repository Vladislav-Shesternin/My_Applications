package com.dogbytegames.offtheroa.game.box2d

object BodyId {
    const val NONE = "none"

    const val ITEM   = "ITEM"
    const val SOBAKA = "SOBAKA"
}