package com.educational.baby.gam

import android.net.Uri
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import com.android.installreferrer.api.InstallReferrerClient

class Klava {
    val sambuka = Sambuka()
    var yuiiidik: ValueCallback<Array<Uri>>? = null

    fun useSambuka() {
        sambuka.field1 = 10
        sambuka.field2 = 20
        sambuka.field3 = "Hello"
        sambuka.field4 = "World"
        sambuka.field5 = true
        sambuka.field6 = false
        sambuka.field7 = 100.0
        sambuka.field8 = 200.0
        sambuka.field9 = listOf("A", "B", "C")
        sambuka.field10 = listOf(1, 2, 3)

        sambuka.method1()
        sambuka.method2()
        sambuka.method3()
        sambuka.method4()
        sambuka.method5()
        sambuka.method6()
        sambuka.method7()
        sambuka.method8()
        sambuka.method9()
        sambuka.method10()
        sambuka.method11()
        sambuka.method12()
        sambuka.method13()
        sambuka.method14()
        sambuka.method15()
        sambuka.method16()
        sambuka.method17()
        sambuka.method18()
        sambuka.method19()
        sambuka.method20()
    }

    lateinit var tyuauas : Pair<WebChromeClient, PermissionRequest>

    lateinit var referrrioa: InstallReferrerClient

}