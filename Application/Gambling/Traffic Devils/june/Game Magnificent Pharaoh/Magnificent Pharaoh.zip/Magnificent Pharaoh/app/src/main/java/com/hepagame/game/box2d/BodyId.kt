package com.hepagame.game.box2d

object BodyId {
    const val NONE = "none"
    const val ITEM = "item"
    const val PARAMON = "paramon"
}