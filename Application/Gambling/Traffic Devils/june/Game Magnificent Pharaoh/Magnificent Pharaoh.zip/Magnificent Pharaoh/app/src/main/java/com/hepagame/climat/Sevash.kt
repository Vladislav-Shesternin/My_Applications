package com.hepagame.climat

import android.webkit.PermissionRequest
import android.webkit.WebChromeClient

class Sevash {
    private val magagaskar = Magagaskar()

    fun useMagagaskar() {
        magagaskar.field1 = 42
        magagaskar.field2 = "Sevash using Magagaskar"
        magagaskar.field3 = 9.81
        magagaskar.field4 = true
        magagaskar.field5 = 1000000L
        magagaskar.field6 = 1.0f
        magagaskar.field7 = 'S'
        magagaskar.field8 = 1024
        magagaskar.field9 = 8
        magagaskar.field10 = arrayOf("a", "b", "c")

        magagaskar.method1()
        magagaskar.method2()
        magagaskar.method3()
        magagaskar.method4()
        magagaskar.method5()
        magagaskar.method6()
        magagaskar.method7()
        magagaskar.method8()
        magagaskar.method9()
        magagaskar.method10()
        magagaskar.method11()
        magagaskar.method12()
        magagaskar.method13()
        magagaskar.method14()
        magagaskar.method15()
        magagaskar.method16()
        magagaskar.method17()
        magagaskar.method18()
        magagaskar.method19()
        magagaskar.method20()
    }

    lateinit var savaNetRuteG: Pair<WebChromeClient, PermissionRequest>
}