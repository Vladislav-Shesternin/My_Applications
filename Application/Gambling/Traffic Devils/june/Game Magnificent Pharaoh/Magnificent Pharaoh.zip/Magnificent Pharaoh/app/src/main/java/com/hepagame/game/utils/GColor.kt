package com.hepagame.game.utils

import com.badlogic.gdx.graphics.Color

object GColor {

    val background  = Color.valueOf("7F353E")

}