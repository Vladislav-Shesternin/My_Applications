package com.duckduckmoosedesign.cpkid.game.box2d

object BodyId {
    const val NONE = "none"
    const val TRIANGLE = "TRIANGLE"
    const val ITEM = "item"
    const val PARAMON = "paramon"
}