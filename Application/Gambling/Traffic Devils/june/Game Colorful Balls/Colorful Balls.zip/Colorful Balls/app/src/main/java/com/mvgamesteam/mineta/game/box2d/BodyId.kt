package com.mvgamesteam.mineta.game.box2d

object BodyId {
    const val NONE = "none"

    const val STRELKI = "STRELKI"
    const val ITEM    = "ITEM"
    const val TRIANGULARIA = "TRIANGULARIA"
}