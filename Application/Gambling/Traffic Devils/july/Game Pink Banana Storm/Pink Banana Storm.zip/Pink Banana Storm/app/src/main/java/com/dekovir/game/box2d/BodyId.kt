package com.dekovir.game.box2d

object BodyId {
    const val NONE = "none"

    const val ITEM = "ITEM"
    const val BALL = "BALL"
    const val PLTF = "PLTF"
    const val RECT = "RECT"
}