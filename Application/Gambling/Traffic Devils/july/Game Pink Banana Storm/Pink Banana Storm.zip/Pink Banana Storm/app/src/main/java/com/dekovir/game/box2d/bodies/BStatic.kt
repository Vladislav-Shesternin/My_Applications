package com.dekovir.game.box2d.bodies

import com.badlogic.gdx.physics.box2d.BodyDef
import com.badlogic.gdx.physics.box2d.FixtureDef
import com.dekovir.game.actors.AImage
import com.dekovir.game.box2d.AbstractBody
import com.dekovir.game.utils.advanced.AdvancedBox2dScreen
import com.dekovir.game.utils.advanced.AdvancedGroup
import java.util.concurrent.atomic.AtomicBoolean

class BStatic(override val screenBox2d: AdvancedBox2dScreen): AbstractBody() {
    override val name       = "circle"
    override val bodyDef    = BodyDef().apply {
        type = BodyDef.BodyType.StaticBody
    }
    override val fixtureDef = FixtureDef()

}