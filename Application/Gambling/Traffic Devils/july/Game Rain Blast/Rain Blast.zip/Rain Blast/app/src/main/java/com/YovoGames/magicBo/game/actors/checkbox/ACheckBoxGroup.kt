package com.JindoBlu.game.actors.checkbox

import com.YovoGames.magicBo.game.actors.checkbox.ACheckBox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}