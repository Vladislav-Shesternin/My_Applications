package com.YovoGames.magicBo.game.box2d

object BodyId {
    const val NONE = "none"

    const val ITEM = "ITEM"
    const val PAR  = "PAR"
}