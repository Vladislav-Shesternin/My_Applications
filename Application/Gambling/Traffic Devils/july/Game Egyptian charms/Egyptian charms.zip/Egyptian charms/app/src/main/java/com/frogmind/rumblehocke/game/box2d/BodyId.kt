package com.frogmind.rumblehocke.game.box2d

object BodyId {
    const val NONE = "none"

    const val ITEM = "ITEM"
    const val PAR  = "PAR"
}