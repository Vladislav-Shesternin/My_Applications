package com.JindoBlu.game.actors.checkbox

import com.frogmind.rumblehocke.game.actors.checkbox.ACheckBox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}