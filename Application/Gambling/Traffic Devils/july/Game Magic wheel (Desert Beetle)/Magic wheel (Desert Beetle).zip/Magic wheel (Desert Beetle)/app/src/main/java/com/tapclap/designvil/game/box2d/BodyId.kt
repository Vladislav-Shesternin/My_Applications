package com.tapclap.designvil.game.box2d

object BodyId {
    const val NONE = "none"

    const val ITEM       = "ITEM"
    const val SUPER_ITEM = "SUPER_ITEM"
    const val PRINCESSA  = "PRINCESSA"
}