package com.JindoBlu.game.actors.checkbox

import com.tapclap.designvil.game.actors.checkbox.ACheckBox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}