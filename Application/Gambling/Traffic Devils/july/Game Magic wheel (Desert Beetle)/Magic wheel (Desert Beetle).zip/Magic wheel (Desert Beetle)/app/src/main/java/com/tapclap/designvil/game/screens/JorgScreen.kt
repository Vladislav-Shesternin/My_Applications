package com.tapclap.designvil.game.screens

import com.badlogic.gdx.scenes.scene2d.Actor
import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.tapclap.designvil.game.LibGDXGame
import com.tapclap.designvil.game.utils.TIME_ANIM
import com.tapclap.designvil.game.utils.actor.animHide
import com.tapclap.designvil.game.utils.actor.animShow
import com.tapclap.designvil.game.utils.actor.setOnClickListener
import com.tapclap.designvil.game.utils.advanced.AdvancedScreen
import com.tapclap.designvil.game.utils.advanced.AdvancedStage
import com.tapclap.designvil.game.utils.region

class JorgScreen(override val game: LibGDXGame): AdvancedScreen() {

    override fun show() {
        stageUI.root.animHide()
        setBackBackground(game.aaa.back.random().region)
        super.show()
        stageUI.root.animShow(TIME_ANIM)
    }

    private fun hideScreen(block: () -> Unit) {
        stageUI.root.animHide(TIME_ANIM) { block.invoke() }
    }

    override fun AdvancedStage.addActorsOnStageUI() {
        val dialogImg = Image(game.bbb.Jorg)
        addActor(dialogImg)
        dialogImg.setBounds(30f, 90f, 479f, 734f)

        val agreeActor    = Actor()
        val disagreeActor = Actor()

        addActors(agreeActor, disagreeActor)

        agreeActor.setBounds(310f, 90f, 188f, 78f)
        disagreeActor.setBounds(42f, 90f, 188f, 78f)

        agreeActor.setOnClickListener(game.soundUtil) {
            game.prefsDialog.edit().putBoolean("IZmaIl", true).apply()
            hideScreen { game.navigationManager.navigate(MenuScreen::class.java.name) }
        }
        disagreeActor.setOnClickListener(game.soundUtil) {
            game.prefsDialog.edit().putBoolean("IZmaIl", true).apply()
            hideScreen { game.navigationManager.navigate(MenuScreen::class.java.name) }
        }

    }

}