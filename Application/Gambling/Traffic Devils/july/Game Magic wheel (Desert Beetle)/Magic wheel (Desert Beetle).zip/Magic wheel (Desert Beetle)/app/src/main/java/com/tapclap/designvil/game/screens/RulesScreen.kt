package com.tapclap.designvil.game.screens

import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.tapclap.designvil.game.LibGDXGame
import com.tapclap.designvil.game.actors.AButton
import com.tapclap.designvil.game.utils.TIME_ANIM
import com.tapclap.designvil.game.utils.actor.animHide
import com.tapclap.designvil.game.utils.actor.animShow
import com.tapclap.designvil.game.utils.actor.setOnClickListener
import com.tapclap.designvil.game.utils.advanced.AdvancedScreen
import com.tapclap.designvil.game.utils.advanced.AdvancedStage
import com.tapclap.designvil.game.utils.region

class RulesScreen(override val game: LibGDXGame) : AdvancedScreen() {

    private val rules = Image(game.bbb.qsde)
    private val back  = AButton(this, AButton.Static.Type.Back)

    override fun show() {
        stageUI.root.animHide()
        setBackBackground(game.aaa.back.random().region)
        super.show()
        stageUI.root.animShow(TIME_ANIM)
    }

    override fun AdvancedStage.addActorsOnStageUI() {
        addActor(rules.apply { setBounds(30f, 256f, 479f, 568f) })

        addActor(back)
        back.apply {
            setBounds(176f, 90f, 188f, 78f)
            setOnClickListener { stageUI.root.animHide(TIME_ANIM) { game.navigationManager.back() } }
        }

    }

}