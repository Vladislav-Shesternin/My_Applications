package com.JindoBlu.game.actors.checkbox

import com.kongregate.mobile.burrit.game.actors.checkbox.ACheckBox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}