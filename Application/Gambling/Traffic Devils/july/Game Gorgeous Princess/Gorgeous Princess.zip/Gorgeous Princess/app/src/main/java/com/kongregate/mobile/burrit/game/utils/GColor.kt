package com.kongregate.mobile.burrit.game.utils

import com.badlogic.gdx.graphics.Color

object GColor {

    val bckg = Color.valueOf("111111")

}