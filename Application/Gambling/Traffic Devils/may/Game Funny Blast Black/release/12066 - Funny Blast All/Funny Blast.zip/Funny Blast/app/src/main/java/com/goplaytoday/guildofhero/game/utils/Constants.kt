package com.goplaytoday.guildofhero.game.utils

const val WIDTH_UI  = 1700f
const val HEIGHT_UI = 1080f

const val TIME_ANIM_ALPHA = 0.4f