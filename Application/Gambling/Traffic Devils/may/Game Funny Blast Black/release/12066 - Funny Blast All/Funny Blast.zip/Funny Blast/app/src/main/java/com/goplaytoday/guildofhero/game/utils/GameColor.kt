package com.goplaytoday.guildofhero.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background = Color.valueOf("883DAC")

}