package com.tutotoons.app.kpopsiescuteunicornpet.game.manager.util

import com.tutotoons.app.kpopsiescuteunicornpet.game.manager.ParticleEffectManager

class ParticleEffectUtil {

    private val Boom_1 = ParticleEffectManager.EnumParticleEffect.Boom_1.data.effect
    private val Boom_2 = ParticleEffectManager.EnumParticleEffect.Boom_2.data.effect
    private val Boom_3 = ParticleEffectManager.EnumParticleEffect.Boom_3.data.effect
    private val Boom_4 = ParticleEffectManager.EnumParticleEffect.Boom_4.data.effect
    private val Boom_5 = ParticleEffectManager.EnumParticleEffect.Boom_5.data.effect
    private val Boom_6 = ParticleEffectManager.EnumParticleEffect.Boom_6.data.effect
    private val Boom_7 = ParticleEffectManager.EnumParticleEffect.Boom_7.data.effect
    private val Boom_8 = ParticleEffectManager.EnumParticleEffect.Boom_8.data.effect

    val listBoom = listOf(Boom_1, Boom_2, Boom_3, Boom_4, Boom_5, Boom_6, Boom_7, Boom_8)

}

