package com.flaregames.olympusrisin.game.utils

import com.badlogic.gdx.graphics.Color

object GColor {

    val background  = Color.valueOf("8A2FBC")
    val black  = Color.valueOf("05031B")

}