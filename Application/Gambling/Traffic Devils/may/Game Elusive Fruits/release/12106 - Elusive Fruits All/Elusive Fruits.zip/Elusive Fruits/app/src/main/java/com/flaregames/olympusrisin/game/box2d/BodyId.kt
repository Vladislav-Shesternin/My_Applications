package com.flaregames.olympusrisin.game.box2d

object BodyId {
    const val NONE = "none"
}