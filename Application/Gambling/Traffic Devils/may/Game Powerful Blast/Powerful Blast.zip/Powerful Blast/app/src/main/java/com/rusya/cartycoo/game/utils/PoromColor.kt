package com.rusya.cartycoo.game.utils

import com.badlogic.gdx.graphics.Color

object PoromColor {

    val saburno  = Color.valueOf("88AC36")

}