package com.rusya.cartycoo.game.manager.util

import com.rusya.cartycoo.game.manager.ParticleEffectManager

class ParticleEffectUtil {

    val FruitBoom = ParticleEffectManager.EnumParticleEffect.FruitBoom.data.effect
    val CandyBoom = ParticleEffectManager.EnumParticleEffect.CandyBoom.data.effect

}

