package com.rusya.cartycoo.game.box2d

object BodyId {
    const val NONE    = "none"
}