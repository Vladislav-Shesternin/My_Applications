package com.ninjakiwi.bloonspuzzl.game.box2d

object BodyId {
    const val NONE = "none"
}