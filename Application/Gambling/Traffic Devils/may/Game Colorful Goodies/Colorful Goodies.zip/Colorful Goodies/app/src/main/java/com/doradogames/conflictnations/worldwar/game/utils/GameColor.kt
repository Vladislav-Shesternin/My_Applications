package com.doradogames.conflictnations.worldwar.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background:Color = Color.valueOf("1F015A")
    val whiter    :Color = Color.valueOf("FFFCFC")

}