package com.doradogames.conflictnations.worldwar.game.manager.util

import com.doradogames.conflictnations.worldwar.game.manager.ParticleEffectManager

class ParticleEffectUtil {

    val FOUNTAIN = ParticleEffectManager.EnumParticleEffect.FOUNTAIN.data.effect

}

