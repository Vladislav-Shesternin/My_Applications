package com.JindoBlu.game.actors.autoLayout

object AutoLayout {
    enum class AlignmentHorizontal {
        START, CENTER, END
    }
    enum class AlignmentVertical {
        BOTTOM, CENTER, TOP
    }
}