package com.JindoBlu.game.actors.slots.slot5x4

/** SlotMatrix5x4
 *
 * 5 slots 4 rows
 * aN..cN - SlitItem index
 *
 * */
data class Matrix5x4(
    val resultMatrix5x4: ResultMatrix5x4? = null,

    val a1: Int,
    val a2: Int,
    val a3: Int,
    val a4: Int,

    val b1: Int,
    val b2: Int,
    val b3: Int,
    val b4: Int,

    val c1: Int,
    val c2: Int,
    val c3: Int,
    val c4: Int,

    val d1: Int,
    val d2: Int,
    val d3: Int,
    val d4: Int,

    val e1: Int,
    val e2: Int,
    val e3: Int,
    val e4: Int,
)

/** ResultMatrix5x4
 *
 * false - fail
 * true  - win
 *
* */
data class ResultMatrix5x4(
    val a1: Boolean,
    val a2: Boolean,
    val a3: Boolean,
    val a4: Boolean,

    val b1: Boolean,
    val b2: Boolean,
    val b3: Boolean,
    val b4: Boolean,

    val c1: Boolean,
    val c2: Boolean,
    val c3: Boolean,
    val c4: Boolean,

    val d1: Boolean,
    val d2: Boolean,
    val d3: Boolean,
    val d4: Boolean,

    val e1: Boolean,
    val e2: Boolean,
    val e3: Boolean,
    val e4: Boolean,
)