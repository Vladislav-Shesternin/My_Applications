package com.JindoBlu.game.manager.util

import com.badlogic.gdx.audio.Sound
import com.JindoBlu.game.manager.AudioManager
import com.JindoBlu.game.utils.runGDX
import com.JindoBlu.game.manager.SoundManager

class SoundUtil {

    val CLICK   = SoundManager.EnumSound.CLICK.data.sound
    val SPINING = SoundManager.EnumSound.SPINING.data.sound
    val STAKE   = SoundManager.EnumSound.STAKE.data.sound
    val WIN     = SoundManager.EnumSound.WIN.data.sound


    // 0..100
    var volumeLevel = AudioManager.volumeLevelPercent

    var isPause = (volumeLevel <= 0f)

    fun play(sound: Sound, coff: Float = 1f) = runGDX { if (isPause.not()) sound.play((volumeLevel / 100f) * coff) }
}