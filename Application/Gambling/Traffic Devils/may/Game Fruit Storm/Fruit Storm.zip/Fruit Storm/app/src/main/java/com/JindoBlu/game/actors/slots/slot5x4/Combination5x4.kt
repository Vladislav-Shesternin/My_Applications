package com.JindoBlu.game.actors.slots.slot5x4

interface ICombinationMatrix5x4 {
    val matrixList: List<Matrix5x4>
}
//WILD index = null (example 12)
/**
 *
 * ITEM index = 0..10
 *
 * */
object Combination5x4 {

    object Mix : ICombinationMatrix5x4 {
        val _1 = Matrix5x4(
            a1 = 0, b1 = 3, c1 = 6, d1 = 9, e1 = 3,
            a2 = 1, b2 = 4, c2 = 7, d2 = 10, e2 = 0,
            a3 = 2, b3 = 5, c3 = 8, d3 = 1, e3 = 4,
            a4 = 3, b4 = 10, c4 = 8, d4 = 2, e4 = 5,
        )
        val _2 = Matrix5x4(
            a1 = 0, b1 = 3, c1 = 6, d1 = 9, e1 = 3,
            a2 = 0, b2 = 4, c2 = 7, d2 = 7, e2 = 0,
            a3 = 2, b3 = 5, c3 = 8, d3 = 1, e3 = 4,
            a4 = 3, b4 = 10, c4 = 8, d4 = 2, e4 = 5,
        )
        val _3 = Matrix5x4(
            a1 = 5, b1 = 3, c1 = 6, d1 = 9, e1 = 4,
            a2 = 1, b2 = 4, c2 = 7, d2 = 10, e2 = 0,
            a3 = 7, b3 = 5, c3 = 8, d3 = 1, e3 = 4,
            a4 = 3, b4 = 10, c4 = 8, d4 = 2, e4 = 10,
        )

        override val matrixList = listOf<Matrix5x4>(_1, _2, _3)
    }

    object Win : ICombinationMatrix5x4 {
        val _1 = Matrix5x4(
            a1 = 0, b1 = 1, c1 = 8, d1 = 9, e1 = 3,
            a2 = 0, b2 = 2, c2 = 7, d2 = 10, e2 = 4,
            a3 = 0, b3 = 3, c3 = 6, d3 = 1, e3 = 5,
            a4 = 0, b4 = 4, c4 = 5, d4 = 2, e4 = 6,

            resultMatrix5x4 = ResultMatrix5x4(
                a1 = true, b1 = false, c1 = false, d1 = false, e1 = false,
                a2 = true, b2 = false, c2 = false, d2 = false, e2 = false,
                a3 = true, b3 = false, c3 = false, d3 = false, e3 = false,
                a4 = true, b4 = false, c4 = false, d4 = false, e4 = false,
            )
        )
        val _2 = Matrix5x4(
            a1 = 1, b1 = 0, c1 = 8, d1 = 9, e1 = 3,
            a2 = 2, b2 = 0, c2 = 7, d2 = 10, e2 = 4,
            a3 = 3, b3 = 0, c3 = 6, d3 = 1, e3 = 5,
            a4 = 4, b4 = 0, c4 = 5, d4 = 2, e4 = 6,

            resultMatrix5x4 = ResultMatrix5x4(
                a1 = false, b1 = true, c1 = false, d1 = false, e1 = false,
                a2 = false, b2 = true, c2 = false, d2 = false, e2 = false,
                a3 = false, b3 = true, c3 = false, d3 = false, e3 = false,
                a4 = false, b4 = true, c4 = false, d4 = false, e4 = false,
            )
        )
        val _3 = Matrix5x4(
            a1 = 1, b1 = 8, c1 = 0, d1 = 9, e1 = 3,
            a2 = 2, b2 = 7, c2 = 0, d2 = 10, e2 = 4,
            a3 = 3, b3 = 6, c3 = 0, d3 = 1, e3 = 5,
            a4 = 4, b4 = 5, c4 = 0, d4 = 2, e4 = 6,

            resultMatrix5x4 = ResultMatrix5x4(
                a1 = false, b1 = false, c1 = true, d1 = false, e1 = false,
                a2 = false, b2 = false, c2 = true, d2 = false, e2 = false,
                a3 = false, b3 = false, c3 = true, d3 = false, e3 = false,
                a4 = false, b4 = false, c4 = true, d4 = false, e4 = false,
            )
        )
        val _4 = Matrix5x4(
            a1 = 1, b1 = 8, c1 = 9, d1 = 0, e1 = 3,
            a2 = 2, b2 = 7, c2 = 10, d2 = 0, e2 = 4,
            a3 = 3, b3 = 6, c3 = 1, d3 = 0, e3 = 5,
            a4 = 4, b4 = 5, c4 = 2, d4 = 0, e4 = 6,

            resultMatrix5x4 = ResultMatrix5x4(
                a1 = false, b1 = false, c1 = false, d1 = true, e1 = false,
                a2 = false, b2 = false, c2 = false, d2 = true, e2 = false,
                a3 = false, b3 = false, c3 = false, d3 = true, e3 = false,
                a4 = false, b4 = false, c4 = false, d4 = true, e4 = false,
            )
        )
        val _5 = Matrix5x4(
            a1 = 1, b1 = 8, c1 = 9, d1 = 3, e1 = 0,
            a2 = 2, b2 = 7, c2 = 10, d2 = 4, e2 = 0,
            a3 = 3, b3 = 6, c3 = 1, d3 = 5, e3 = 0,
            a4 = 4, b4 = 5, c4 = 2, d4 = 6, e4 = 0,

            resultMatrix5x4 = ResultMatrix5x4(
                a1 = false, b1 = false, c1 = false, d1 = false, e1 = true,
                a2 = false, b2 = false, c2 = false, d2 = false, e2 = true,
                a3 = false, b3 = false, c3 = false, d3 = false, e3 = true,
                a4 = false, b4 = false, c4 = false, d4 = false, e4 = true,
            )
        )

        val _6 = Matrix5x4(
            a1 = 0, b1 = 0, c1 = 0, d1 = 0, e1 = 0,
            a2 = 2, b2 = 7, c2 = 10, d2 = 4, e2 = 7,
            a3 = 3, b3 = 6, c3 = 1, d3 = 5, e3 = 8,
            a4 = 4, b4 = 5, c4 = 2, d4 = 6, e4 = 10,

            resultMatrix5x4 = ResultMatrix5x4(
                a1 = true, b1 = true, c1 = true, d1 = true, e1 = true,
                a2 = false, b2 = false, c2 = false, d2 = false, e2 = false,
                a3 = false, b3 = false, c3 = false, d3 = false, e3 = false,
                a4 = false, b4 = false, c4 = false, d4 = false, e4 = false,
            )
        )
        val _7 = Matrix5x4(
            a1 = 2, b1 = 7, c1 = 10, d1 = 4, e1 = 7,
            a2 = 0, b2 = 0, c2 = 0, d2 = 0, e2 = 0,
            a3 = 3, b3 = 6, c3 = 1, d3 = 5, e3 = 8,
            a4 = 4, b4 = 5, c4 = 2, d4 = 6, e4 = 10,

            resultMatrix5x4 = ResultMatrix5x4(
                a1 = false, b1 = false, c1 = false, d1 = false, e1 = false,
                a2 = true, b2 = true, c2 = true, d2 = true, e2 = true,
                a3 = false, b3 = false, c3 = false, d3 = false, e3 = false,
                a4 = false, b4 = false, c4 = false, d4 = false, e4 = false,
            )
        )
        val _8 = Matrix5x4(
            a1 = 2, b1 = 7, c1 = 10, d1 = 4, e1 = 7,
            a2 = 3, b2 = 6, c2 = 1, d2 = 5, e2 = 8,
            a3 = 0, b3 = 0, c3 = 0, d3 = 0, e3 = 0,
            a4 = 4, b4 = 5, c4 = 2, d4 = 6, e4 = 10,

            resultMatrix5x4 = ResultMatrix5x4(
                a1 = false, b1 = false, c1 = false, d1 = false, e1 = false,
                a2 = false, b2 = false, c2 = false, d2 = false, e2 = false,
                a3 = true, b3 = true, c3 = true, d3 = true, e3 = true,
                a4 = false, b4 = false, c4 = false, d4 = false, e4 = false,
            )
        )
        val _9 = Matrix5x4(
            a1 = 2, b1 = 7, c1 = 10, d1 = 4, e1 = 7,
            a2 = 3, b2 = 6, c2 = 1, d2 = 5, e2 = 8,
            a3 = 4, b3 = 5, c3 = 2, d3 = 6, e3 = 10,
            a4 = 0, b4 = 0, c4 = 0, d4 = 0, e4 = 0,

            resultMatrix5x4 = ResultMatrix5x4(
                a1 = false, b1 = false, c1 = false, d1 = false, e1 = false,
                a2 = false, b2 = false, c2 = false, d2 = false, e2 = false,
                a3 = false, b3 = false, c3 = false, d3 = false, e3 = false,
                a4 = true, b4 = true, c4 = true, d4 = true, e4 = true,
            )
        )

        override val matrixList = listOf<Matrix5x4>(_1, _2, _3, _4, _5, _6, _7, _8, _9)
    }

}