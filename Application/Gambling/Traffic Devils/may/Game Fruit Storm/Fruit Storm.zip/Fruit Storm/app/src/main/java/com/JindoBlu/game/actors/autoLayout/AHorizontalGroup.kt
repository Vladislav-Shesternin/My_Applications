package com.JindoBlu.game.actors.autoLayout

import com.JindoBlu.game.utils.advanced.AdvancedGroup
import com.JindoBlu.game.utils.advanced.AdvancedScreen
import com.badlogic.gdx.scenes.scene2d.Actor

class AHorizontalGroup(
    override val screen: AdvancedScreen,
    val gap      : Float = 0f,
    val startGap : Float = gap,
    val endGap   : Float = gap,
    val alignmentH: AutoLayout.AlignmentHorizontal = AutoLayout.AlignmentHorizontal.START,
    val alignmentV: AutoLayout.AlignmentVertical   = AutoLayout.AlignmentVertical.BOTTOM,
    val direction : Static.Direction = Static.Direction.RIGHT,
    val isParentScrollPane: Boolean = false
) : AdvancedGroup() {

    private var nx       = 0f
    private var newWidth = 0f

    override fun getPrefWidth(): Float {
        if (isParentScrollPane) {
            newWidth = 0f
            children.onEach { newWidth += it.width + gap }

            newWidth -= gap
            newWidth += startGap + endGap

            if (alignmentH == AutoLayout.AlignmentHorizontal.END && parent.width > newWidth) newWidth = parent.width
        } else {
            newWidth = width
        }

        return newWidth
    }

    override fun getPrefHeight(): Float {
        return height
    }

    override fun addActorsOnGroup() {}

    override fun childrenChanged() {
        super.childrenChanged()
        placeChildren()
    }

    private fun placeChildren() {
        when (alignmentH) {
            AutoLayout.AlignmentHorizontal.START -> {
                nx = 0f

                when (direction) {
                    Static.Direction.LEFT -> children.reversed().onEachIndexed { index, a -> a.moveFromSTART(index) }
                    Static.Direction.RIGHT -> children.onEachIndexed { index, a -> a.moveFromSTART(index) }
                }
            }
            AutoLayout.AlignmentHorizontal.CENTER -> {
                val childrenWidth = children.map { it.width }.sum()
                val gapWidth      = (gap * children.count().dec())
                nx = (prefWidth / 2) - ((childrenWidth + gapWidth) / 2)

                when (direction) {
                    Static.Direction.LEFT -> children.reversed().onEach { a -> a.moveFromCENTER() }
                    Static.Direction.RIGHT -> children.onEach { a -> a.moveFromCENTER() }
                }
            }
            AutoLayout.AlignmentHorizontal.END -> {
                nx = prefWidth

                when (direction) {
                    Static.Direction.LEFT -> children.onEachIndexed { index, a -> a.moveFromEND(index) }
                    Static.Direction.RIGHT -> children.reversed().onEachIndexed { index, a -> a.moveFromEND(index) }
                }
            }
        }

        when(alignmentV) {
            AutoLayout.AlignmentVertical.BOTTOM -> {
                children.onEach { it.y = 0f }
            }
            AutoLayout.AlignmentVertical.CENTER -> {
                children.onEach { it.y = (height / 2) - (it.height / 2) }
            }
            AutoLayout.AlignmentVertical.TOP -> {
                children.onEach { it.y = height - it.height }
            }
        }
    }

    private fun Int.gap() = (if (this == 0) startGap else gap)

    private fun Actor.moveFromSTART(index: Int) {
        nx += index.gap()
        x = nx
        nx += width
    }

    private fun Actor.moveFromEND(index: Int) {
        nx -= (index.gap() + width)
        x = nx
    }

    private fun Actor.moveFromCENTER() {
        x = nx
        nx += (width + gap)
    }

    object Static {
        enum class Direction {
            LEFT, RIGHT
        }
    }

}