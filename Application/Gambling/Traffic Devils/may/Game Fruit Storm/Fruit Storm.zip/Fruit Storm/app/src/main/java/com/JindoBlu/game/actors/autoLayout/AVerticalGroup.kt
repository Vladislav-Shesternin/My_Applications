package com.JindoBlu.game.actors.autoLayout

import com.JindoBlu.game.utils.advanced.AdvancedGroup
import com.JindoBlu.game.utils.advanced.AdvancedScreen
import com.badlogic.gdx.scenes.scene2d.Actor

class AVerticalGroup(
    override val screen: AdvancedScreen,
    val gap      : Float = 0f,
    val startGap : Float = gap,
    val endGap   : Float = gap,
    val alignmentV: AutoLayout.AlignmentVertical   = AutoLayout.AlignmentVertical.TOP,
    val alignmentH: AutoLayout.AlignmentHorizontal = AutoLayout.AlignmentHorizontal.START,
    val direction : Static.Direction = AVerticalGroup.Static.Direction.DOWN,
    val isParentScrollPane: Boolean = false
) : AdvancedGroup() {

    private var ny        = 0f
    private var newHeight = 0f

    override fun getPrefWidth(): Float {
        return width
    }

    override fun getPrefHeight(): Float {
        if (isParentScrollPane) {
            newHeight = 0f
            children.onEach { newHeight += it.height + gap }

            newHeight -= gap
            newHeight += startGap + endGap

            if (alignmentV == AutoLayout.AlignmentVertical.BOTTOM && parent.height > newHeight) newHeight = parent.height
        } else {
            newHeight = height
        }

        return newHeight
    }

    override fun addActorsOnGroup() {}

    override fun childrenChanged() {
        super.childrenChanged()
        placeChildren()
    }

    private fun placeChildren() {
        when (alignmentV) {
            AutoLayout.AlignmentVertical.TOP -> {
                ny = prefHeight

                when (direction) {
                    Static.Direction.DOWN -> children.onEachIndexed { index, a -> a.moveFromTOP(index) }
                    Static.Direction.UP   -> children.reversed().onEachIndexed { index, a -> a.moveFromTOP(index) }
                }
            }
            AutoLayout.AlignmentVertical.CENTER -> {
                val childrenHeight = children.map { it.height }.sum()
                val gapHeight      = (gap * children.count().dec())
                ny = (prefHeight / 2) - ((childrenHeight + gapHeight) / 2)

                when (direction) {
                    Static.Direction.UP   -> children.onEach { a -> a.moveFromCENTER() }
                    Static.Direction.DOWN -> children.reversed().onEach { a -> a.moveFromCENTER() }
                }
            }
            AutoLayout.AlignmentVertical.BOTTOM -> {
                ny = 0f

                when (direction) {
                    Static.Direction.UP -> children.onEachIndexed { index, a -> a.moveFromBOTTOM(index) }
                    Static.Direction.DOWN -> children.reversed().onEachIndexed { index, a -> a.moveFromBOTTOM(index) }
                }
            }
        }

        when(alignmentH) {
            AutoLayout.AlignmentHorizontal.START -> {
                children.onEach { it.x = 0f }
            }
            AutoLayout.AlignmentHorizontal.CENTER -> {
                children.onEach { it.x = (width / 2) - (it.width / 2) }
            }
            AutoLayout.AlignmentHorizontal.END -> {
                children.onEach { it.x = width - it.width }
            }
        }
    }

    private fun Int.gap() = (if (this == 0) startGap else gap)

    private fun Actor.moveFromTOP(index: Int) {
        ny -= (index.gap() + height)
        y  = ny
    }

    private fun Actor.moveFromBOTTOM(index: Int) {
        ny += index.gap()
        y  = ny
        ny += height
    }

    private fun Actor.moveFromCENTER() {
        y = ny
        ny += (height + gap)
    }

    object Static {
        enum class Direction {
            UP, DOWN
        }
    }

}