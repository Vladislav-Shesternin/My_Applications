package com.JindoBlu.game.manager

import com.badlogic.gdx.assets.AssetManager
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.TextureAtlas

class SpriteManager(var assetManager: AssetManager) {

    var loadableAtlasList   = mutableListOf<AtlasData>()
    var loadableTexturesList   = mutableListOf<TextureData>()

    fun loadAtlas() {
        loadableAtlasList.onEach { assetManager.load(it.path, TextureAtlas::class.java) }
    }

    fun initAtlas() {
        loadableAtlasList.onEach { it.atlas = assetManager[it.path, TextureAtlas::class.java] }
        loadableAtlasList.clear()
    }

    // Texture
    fun loadTexture() {
        loadableTexturesList.onEach { assetManager.load(it.path, Texture::class.java) }
    }

    fun initTexture() {
        loadableTexturesList.onEach { it.texture = assetManager[it.path, Texture::class.java] }
        loadableTexturesList.clear()
    }

    fun initAtlasAndTexture() {
        initAtlas()
        initTexture()
    }


    enum class EnumAtlas(val data: AtlasData) {
        All(AtlasData("atlas/all.atlas")),
    }

    enum class EnumTexture(val data: TextureData) {
        MAIN_BACKGROUND(TextureData("textures/loader/main_background.png")),

        BARABAN    (TextureData("textures/all/baraban.png")),
        MENU       (TextureData("textures/all/menu.png")),
        MUSIC_SOUND(TextureData("textures/all/music_sound.png")),
        PROG_MASK  (TextureData("textures/all/prog_mask.png")),
        RULES      (TextureData("textures/all/rules.png")),

        T_MUSIC(TextureData("textures/all/t_music.png")),
        T_SOUND(TextureData("textures/all/t_sound.png")),
        T_XXX  (TextureData("textures/all/t_xxx.png")),
        T_BACK (TextureData("textures/all/t_back.png")),

        T_G_BALANCE(TextureData("textures/all/t_g_balance.png")),
        T_G_GO     (TextureData("textures/all/t_g_go.png")),
        T_G_STAKE  (TextureData("textures/all/t_g_stake.png")),
    }

    data class AtlasData(val path: String) {
        lateinit var atlas: TextureAtlas
    }

    data class TextureData(val path: String) {
        lateinit var texture: Texture
    }

}