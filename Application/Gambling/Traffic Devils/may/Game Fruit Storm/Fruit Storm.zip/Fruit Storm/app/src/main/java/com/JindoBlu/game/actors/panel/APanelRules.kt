package com.JindoBlu.game.actors.panel

import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.JindoBlu.game.actors.button.AButton
import com.JindoBlu.game.utils.advanced.AdvancedGroup
import com.JindoBlu.game.utils.advanced.AdvancedScreen

class APanelRules(override val screen: AdvancedScreen): AdvancedGroup() {

    val rulesImg = Image(screen.game.assetsAll.RULES)
    val backBtn  = AButton(screen, AButton.Static.Type.Back)

    override fun addActorsOnGroup() {
        addRules()
        addBack()
    }

    // Add Actors
    private fun addRules() {
        addActor(rulesImg)
        rulesImg.setBounds(153f, 234f, 1221f, 573f)
    }

    private fun addBack() {
        addActor(backBtn)
        backBtn.setBounds(636f, 56f, 254f, 89f)
    }

}