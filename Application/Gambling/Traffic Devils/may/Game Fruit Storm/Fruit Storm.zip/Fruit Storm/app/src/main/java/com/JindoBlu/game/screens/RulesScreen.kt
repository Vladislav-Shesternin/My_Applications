package com.JindoBlu.game.screens

import com.JindoBlu.game.GDXGame
import com.JindoBlu.game.actors.ATutorials
import com.JindoBlu.game.actors.panel.APanelRules
import com.JindoBlu.game.utils.*
import com.JindoBlu.game.utils.actor.*
import com.JindoBlu.game.utils.advanced.AdvancedScreen
import com.JindoBlu.game.utils.advanced.AdvancedStage
import kotlinx.coroutines.launch

class RulesScreen(override val game: GDXGame): AdvancedScreen() {

    private val panelRules = APanelRules(this).apply { color.a = 0f }
    private val tutorials  = ATutorials(this).apply { color.a = 0f }

    override fun show() {
        setBackBackground(game.assetsLoader.MAIN_BACKGROUND.region)
        super.show()
    }

    override fun hideScreen(block: Block) {
        coroutine?.launch {
            if (game.isTutorialsUtil.isTutorials) tutorials.animHideSuspend(TIME_ANIM_SCREEN_ALPHA)
            animHidePanelSuspend(panelRules) { block.invoke() }
        }
    }

    override fun AdvancedStage.addActorsOnStageUI() {
        coroutine?.launch {
            runGDX {
                addPanel()
                if (game.isTutorialsUtil.isTutorials) addTutorials()
            }
            animShowPanelSuspend(panelRules)
            if (game.isTutorialsUtil.isTutorials) tutorials.animShowSuspend(TIME_ANIM_SCREEN_ALPHA)
        }
    }

    private fun AdvancedStage.addPanel() {
        addActor(panelRules)
        panelRules.setBounds(0f, -HEIGHT_UI, WIDTH_UI, HEIGHT_UI)

        panelRules.apply {
            backBtn.setOnClickListener {
                hideScreen {
                    if (screen.game.isTutorialsUtil.isTutorials) ATutorials.nextStep()
                    screen.game.navigationManager.back()
                }
            }
        }
    }

    private fun AdvancedStage.addTutorials() {
        addAndFillActor(tutorials)
    }


}