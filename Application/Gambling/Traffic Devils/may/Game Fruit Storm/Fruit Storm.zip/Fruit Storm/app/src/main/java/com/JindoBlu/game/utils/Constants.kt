package com.JindoBlu.game.utils

const val WIDTH_UI  = 1527f
const val HEIGHT_UI = 900f

const val TIME_ANIM_SCREEN_ALPHA = 0.323f