package com.JindoBlu.game.utils.dataStore

import com.JindoBlu.game.manager.GameDataStoreManager
import com.JindoBlu.util.log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

class BalanceUtil(val coroutine: CoroutineScope) {

    var balance = 0
        private set

    init {
        coroutine.launch {
            balance = GameDataStoreManager.Balance.get() ?: 50_000
            log("Store balance = $balance")
        }
    }

    fun update(value: Int) {
        if (value != balance) {
            coroutine.launch {
                balance = value

                log("Store balance update = $balance")
                GameDataStoreManager.Balance.update { balance }
            }
        }
    }

}