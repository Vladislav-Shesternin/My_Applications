package com.JindoBlu.game.actors

import com.badlogic.gdx.math.Interpolation
import com.badlogic.gdx.scenes.scene2d.actions.Actions
import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.badlogic.gdx.scenes.scene2d.ui.Label
import com.badlogic.gdx.utils.Align
import com.JindoBlu.R
import com.JindoBlu.game.actors.button.AButton
import com.JindoBlu.game.actors.mask.InvertedMask
import com.JindoBlu.game.utils.GameColor
import com.JindoBlu.game.utils.HEIGHT_UI
import com.JindoBlu.game.utils.WIDTH_UI
import com.JindoBlu.game.utils.actor.*
import com.JindoBlu.game.utils.advanced.AdvancedGroup
import com.JindoBlu.game.utils.advanced.AdvancedScreen
import com.JindoBlu.game.utils.font.FontParameter
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable

class ATutorials(override val screen: AdvancedScreen) : AdvancedGroup() {

    companion object {
        private var stepIndex = 0

        val STEP get() = Static.Step.entries[stepIndex]

        fun nextStep() {
            if (stepIndex < Static.Step.entries.lastIndex) stepIndex++
        }
    }

    private val fontParameter = FontParameter().setCharacters(FontParameter.CharType.ALL).setSize(40)
    private val font          = screen.fontGenerator_KronaOne.generateFont(fontParameter)

    private val maskRegion     = screen.drawerUtil.getRegion(GameColor.tutor.cpy().apply { a = 0.8f })
    private val mask           = InvertedMask(screen, maskRegion)
    private val visibleAreaImg = Image(screen.game.assetsAll.path)
    private val handImg        = Image(screen.game.assetsAll.click).apply {
        this.setSize(99f, 99f)
        this.disable()
    }
    private val textLbl        = Label("", Label.LabelStyle(font, GameColor.white))
    private val nextBtn        = AButton(screen, AButton.Static.Type.NXT).apply { this.setSize(178f, 68f) }
    private val backgroundImg  = Image()

    // Field
    var menuSettingsBlock = {}
    var gameStakeBlock    = {}
    var gameGoBlock       = {}

    override fun addActorsOnGroup() {
        disable()

        when(STEP) {
            Static.Step.MenuBalance   -> addMenuBalance()
            Static.Step.SettingsMusic -> addSettingsMusic()
            Static.Step.MenuRules     -> addMenuRules()
            Static.Step.RulesBack     -> addRulesBack()
            Static.Step.MenuGame      -> addMenuGame()
            Static.Step.GameBalance   -> addGameBalance()
        }

    }

    // Add ------------------------------------------------------------------------

    fun addMenuBalance() {
        addAndFillActor(mask)

        mask.addActor(visibleAreaImg)
        visibleAreaImg.setBounds(494f,721f,538f,149f)

        enable()
        addActor(nextBtn)
        nextBtn.apply {
            setPosition(674f, 346f)
            setOnClickListener { toMenuMainMenu() }
        }

        addActor(handImg)
        handImg.apply {
            setPosition(825f, 315f)
            animHand()
        }

        addActor(textLbl)
        textLbl.apply {
            setText(screen.game.activity.getString(R.string.tut_menu_balance))
            setBounds(66f, 493f, 1394f, 150f)
            setAlignment(Align.center)
            wrap = true
        }
    }

    fun addSettingsMusic() {
        backgroundImg.drawable = TextureRegionDrawable(screen.game.assetsAll.T_MUSIC)
        addAndFillActor(backgroundImg)

        addActor(handImg)
        handImg.apply {
            setPosition(714f, 571f)
            animHand()
        }

        addActor(textLbl)
        textLbl.apply {
            setText(screen.game.activity.getString(R.string.tut_settings_music))
            setBounds(121f, 723f, 1006f, 141f)
            setAlignment(Align.center)
            wrap = true
        }
    }

    fun addMenuRules() {
        addAndFillActor(mask)

        mask.addActor(visibleAreaImg)
        visibleAreaImg.setBounds(396f,379f,142f,142f)

        addActor(handImg)
        handImg.apply {
            setPosition(502f, 389f)
            animHand()
        }

        addActor(textLbl)
        textLbl.apply {
            setText(screen.game.activity.getString(R.string.tut_menu_rules))
            setBounds(12f, 553f, 953f, 141f)
            setAlignment(Align.center)
            wrap = true
        }
    }

    fun addRulesBack() {
        addAndFillActor(mask)

        mask.addActor(visibleAreaImg)
        visibleAreaImg.setBounds(152f,45f,1223f,763f)

        addActor(handImg)
        handImg.apply {
            setPosition(845f, 29f)
            animHand()
        }
    }

    fun addMenuGame() {
        addAndFillActor(mask)

        mask.addActor(visibleAreaImg)
        visibleAreaImg.setBounds(653f,340f,220f,220f)

        addActor(handImg)
        handImg.apply {
            setPosition(837f, 389f)
            animHand()
        }

        addActor(textLbl)
        textLbl.apply {
            setText(screen.game.activity.getString(R.string.tut_menu_game))
            setBounds(287f, 569f, 953f, 141f)
            setAlignment(Align.center)
            wrap = true
        }
    }

    fun addGameBalance() {
        backgroundImg.drawable = TextureRegionDrawable(screen.game.assetsAll.T_G_BALANCE)
        addAndFillActor(backgroundImg)

        enable()
        addActor(nextBtn)
        nextBtn.apply {
            setPosition(570f, 56f)
            setOnClickListener { toGameStake() }
        }

        addActor(handImg)
        handImg.apply {
            setPosition(721f, 25f)
            animHand()
        }

        addActor(textLbl)
        textLbl.apply {
            setText(screen.game.activity.getString(R.string.tut_game_balance))
            setBounds(26f, 144f, 535f, 141f)
            setAlignment(Align.center)
            wrap = true
        }
    }


    // To ------------------------------------------------------------------------

    fun toMenuMainMenu() {
        nextBtn.apply {
            addAction(Actions.moveTo(674f, 88f, 0.6f))
            setOnClickListener { toMenuSettings() }
        }

        visibleAreaImg.addAction(Actions.parallel(
            Actions.sizeTo(978f, 451f, 0.5f),
            Actions.moveTo(275f, 224f, 0.5f)
        ))

        handImg.addAction(Actions.moveTo(825f, 57f, 0.6f))

        textLbl.apply {
            animHide(0.25f) {
                setText(screen.game.activity.getString(R.string.tut_menu_mainMenu))
                setBounds(66f, 753f, 1394f, 50f)
                setAlignment(Align.center)
                wrap = true
                animShow(0.25f)
            }
        }
    }

    fun toMenuSettings() {
        nextBtn.disable()
        nextBtn.animHide(0.2f)

        visibleAreaImg.addAction(Actions.parallel(
            Actions.sizeTo(142f, 142f, 0.5f),
            Actions.moveTo(977f, 390f, 0.5f)
        ))

        handImg.addAction(Actions.moveTo(1094f, 389f, 0.6f))

        textLbl.apply {
            animHide(0.25f) {
                setText(screen.game.activity.getString(R.string.tut_menu_settings))
                setBounds(566f, 553f, 953f, 141f)
                setAlignment(Align.center)
                wrap = true
                animShow(0.25f) {
                    this@ATutorials.disable()
                    menuSettingsBlock()
                }
            }
        }
    }

    fun toSettingsSound() {
        addAction(Actions.sequence(
            Actions.delay(0.73f),
            Actions.run {
                backgroundImg.drawable = TextureRegionDrawable(screen.game.assetsAll.T_SOUND)

                handImg.addAction(Actions.moveTo(714f, 253f, 0.6f))

                textLbl.apply {
                    animHide(0.25f) {
                        setText(screen.game.activity.getString(R.string.tut_settings_sound))
                        setBounds(121f, 405f, 1006f, 141f)
                        setAlignment(Align.center)
                        wrap = true
                        animShow(0.25f)
                    }
                }
            }
        ))
    }

    fun toSettingsXxx() {
        addAction(Actions.sequence(
            Actions.delay(0.73f),
            Actions.run {
                backgroundImg.drawable = TextureRegionDrawable(screen.game.assetsAll.T_XXX)

                handImg.addAction(Actions.moveTo(575f, 351f, 0.6f))

                textLbl.apply {
                    animHide(0.25f) {
                        setText(screen.game.activity.getString(R.string.tut_settings_xxx))
                        setBounds(99f, 634f, 1051f, 141f)
                        setAlignment(Align.center)
                        wrap = true
                        animShow(0.25f)
                    }
                }
            }
        ))
    }

    fun toSettingsBack() {
        backgroundImg.drawable = TextureRegionDrawable(screen.game.assetsAll.T_BACK)

        handImg.addAction(Actions.moveTo(846f, 29f, 0.6f))

        textLbl.apply {
            animHide(0.25f) {
                setText(screen.game.activity.getString(R.string.tut_settings_back))
                setBounds(238f, 210f, 1051f, 141f)
                setAlignment(Align.center)
                wrap = true
                animShow(0.25f)
            }
        }
    }

    fun toGameStake() {
        nextBtn.disable()
        nextBtn.animHide(0.2f)

        backgroundImg.drawable = TextureRegionDrawable(screen.game.assetsAll.T_G_STAKE)

        handImg.addAction(Actions.moveTo(934f, 41f, 0.6f))

        textLbl.apply {
            animHide(0.25f) {
                setText(screen.game.activity.getString(R.string.tut_game_stake))
                setBounds(542f, 112f, 926f, 297f)
                setAlignment(Align.center)
                wrap = true
                animShow(0.25f) {
                    this@ATutorials.disable()
                    gameStakeBlock()
                }
            }
        }
    }

    fun toGameGo() {
        backgroundImg.drawable = TextureRegionDrawable(screen.game.assetsAll.T_G_GO)

        handImg.addAction(Actions.moveTo(799f, 17f, 0.6f))

        textLbl.apply {
            animHide(0.25f) {
                setText(screen.game.activity.getString(R.string.tut_game_go))
                setBounds(193f, 188f, 1141f, 297f)
                setAlignment(Align.center)
                wrap = true
                animShow(0.25f) {
                    this@ATutorials.disable()
                    gameGoBlock()
                }
            }
        }
    }

    // Anim
    private fun animHand() {
        handImg.apply {
            addAction(Actions.forever(Actions.sequence(
                Actions.alpha(0.3f, 0.5f, Interpolation.slowFast),
                Actions.alpha(1f, 0.25f, Interpolation.fastSlow),
            )))
        }

    }

    object Static {
        enum class Step {
            MenuBalance,
            SettingsMusic,
            MenuRules,
            RulesBack,
            MenuGame,
            GameBalance,
        }
    }

}