package com.JindoBlu.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background:Color = Color.valueOf("69017C")
    val white     :Color = Color.valueOf("F1F1F1")
    val tutor     :Color = Color.valueOf("010304")

}