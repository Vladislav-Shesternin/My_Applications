package com.JindoBlu.game.screens

import com.JindoBlu.game.GDXGame
import com.JindoBlu.game.actors.ATutorials
import com.JindoBlu.game.actors.panel.APanelGame
import com.JindoBlu.game.utils.*
import com.JindoBlu.game.utils.actor.*
import com.JindoBlu.game.utils.advanced.AdvancedScreen
import com.JindoBlu.game.utils.advanced.AdvancedStage
import com.badlogic.gdx.scenes.scene2d.actions.Actions
import kotlinx.coroutines.launch

class GameScreen(override val game: GDXGame): AdvancedScreen() {

    private val panelGame = APanelGame(this).apply { color.a = 0f }
    private val tutorials = ATutorials(this).apply { color.a = 0f }

    override fun show() {
        setBackBackground(game.assetsLoader.MAIN_BACKGROUND.region)
        super.show()
    }

    override fun hideScreen(block: Block) {
        coroutine?.launch {
            panelGame.slotGroup.animHideSuspend(TIME_ANIM_SCREEN_ALPHA)
            animHidePanelSuspend(panelGame) { block.invoke() }
        }
    }

    override fun AdvancedStage.addActorsOnStageUI() {
        coroutine?.launch {
            runGDX {
                addPanel()
                if (game.isTutorialsUtil.isTutorials) addTutorials()
            }
            animShowPanelSuspend(panelGame)
            panelGame.slotGroup.animShowSuspend(TIME_ANIM_SCREEN_ALPHA)

            if (game.isTutorialsUtil.isTutorials) tutorials.animShowSuspend(TIME_ANIM_SCREEN_ALPHA)
        }
    }

    private fun AdvancedStage.addPanel() {
        addActor(panelGame)
        panelGame.setBounds(0f, -HEIGHT_UI, WIDTH_UI, HEIGHT_UI)

        panelGame.apply {
            backBtn.setOnClickListener {
                hideScreen { screen.game.navigationManager.back() }
            }
        }
    }

    private fun AdvancedStage.addTutorials() {
        addAndFillActor(tutorials)

        panelGame.goBlock = {
            tutorials.animHide(TIME_ANIM_SCREEN_ALPHA) {
                tutorials.addAction(Actions.removeActor())
                game.isTutorialsUtil.update(false)
                panelGame.backBtn.enable()
            }
        }

        if (game.isTutorialsUtil.isTutorials) {
            when (ATutorials.STEP) {
                ATutorials.Static.Step.GameBalance -> {
                    panelGame.children.onEach { it.disable() }
                    tutorials.gameStakeBlock = {
                        panelGame.plusBlock = {
                            panelGame.plusBtn.disable()
                            tutorials.gameGoBlock = { panelGame.goBtn.enable() }
                            tutorials.toGameGo()
                        }
                        panelGame.plusBtn.enable()
                    }
                }
                else -> {}
            }
        }
    }


}