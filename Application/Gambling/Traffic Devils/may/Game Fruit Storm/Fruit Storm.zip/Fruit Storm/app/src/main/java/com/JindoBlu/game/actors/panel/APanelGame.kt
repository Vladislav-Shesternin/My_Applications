package com.JindoBlu.game.actors.panel

import com.JindoBlu.game.actors.button.AButton
import com.JindoBlu.game.actors.slots.slot5x4.SlotGroup
import com.JindoBlu.game.utils.GameColor
import com.JindoBlu.game.utils.advanced.AdvancedGroup
import com.JindoBlu.game.utils.advanced.AdvancedScreen
import com.JindoBlu.game.utils.font.FontParameter
import com.JindoBlu.game.utils.runGDX
import com.JindoBlu.game.utils.toBalanceFormat
import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.badlogic.gdx.scenes.scene2d.ui.Label
import com.badlogic.gdx.utils.Align
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class APanelGame(override val screen: AdvancedScreen): AdvancedGroup() {

    private val parameter = FontParameter().setCharacters(FontParameter.CharType.NUMBERS.chars+'.')
    private val font34    = screen.fontGenerator_KronaOne.generateFont(parameter.setSize(34))
    private val font50    = screen.fontGenerator_KronaOne.generateFont(parameter.setSize(50))

    private var stakeIndexFlow = MutableStateFlow(0)
    private var balanceFlow    = MutableStateFlow(screen.game.balanceUtil.balance)
    private val stakeList      = listOf(500, 1000, 2500, 5000, 7500, 10_000)

    val backBtn   = AButton(screen, AButton.Static.Type.Back)
    val slotGroup = SlotGroup(screen).apply { color.a = 0f }

    val goBtn       = AButton(screen, AButton.Static.Type.Go)
    private val coinImg     = Image(screen.game.assetsAll.coin)
    private val balanceLbl  = Label(balanceFlow.value.toBalanceFormat(), Label.LabelStyle(font50, GameColor.white))
    val plusBtn     = AButton(screen, AButton.Static.Type.Plus)
    private val minusBtn    = AButton(screen, AButton.Static.Type.Minus)
    private val stakeLbl    = Label(stakeList[stakeIndexFlow.value].toBalanceFormat(), Label.LabelStyle(font34, GameColor.white))

    var plusBlock = {}
    var goBlock   = {}

    override fun addActorsOnGroup() {
        addBack()
        addBalancePanel()
        addGo()
        addStake()
        addPlusMinus()
        addSlotGroup()
    }

    // Actors ------------------------------------------------------------------------
    private fun addBack() {
        addActor(backBtn)
        backBtn.setBounds(1303f, 57f, 174f, 61f)
    }

    private fun addBalancePanel() {
        addActors(coinImg, balanceLbl)
        coinImg.setBounds(49f, 54f, 80f, 68f)
        balanceLbl.setBounds(156f, 57f, 347f, 63f)

        coroutine?.launch {
            balanceFlow.collect { balance ->
                runGDX { balanceLbl.setText(balance.toBalanceFormat()) }
                screen.game.balanceUtil.update(balance)
            }
        }
    }

    private fun addStake() {
        addActor(stakeLbl)
        stakeLbl.apply {
            setBounds(1011f, 67f, 162f, 43f)
            setAlignment(Align.center)
        }

        coroutine?.launch {
            stakeIndexFlow.collect { index ->
                runGDX { stakeLbl.setText(stakeList[index].toBalanceFormat()) }
            }
        }
    }

    private fun addPlusMinus() {
        addActors(plusBtn, minusBtn)
        plusBtn.apply {
            setBounds(914f, 58f, 69f, 61f)
            setOnClickListener(screen.game.soundUtil.STAKE, 0.5f) {
                if (screen.game.isTutorialsUtil.isTutorials) plusBlock()
                if ((stakeIndexFlow.value + 1) <= stakeList.lastIndex) stakeIndexFlow.value += 1
            }
        }
        minusBtn.apply {
            setBounds(1201f, 58f, 69f, 61f)
            setOnClickListener(screen.game.soundUtil.STAKE, 0.5f) {
                if ((stakeIndexFlow.value - 1) >= 0) stakeIndexFlow.value -= 1
            }
        }
    }

    private fun addSlotGroup() {
        addActor(slotGroup)
        slotGroup.setBounds(49f,172f,1429f,695f)
    }

    private fun addGo() {
        addActor(goBtn)
        goBtn.setBounds(687f, 22f, 153f, 133f)

        val btnList = listOf(goBtn, plusBtn, minusBtn)

        goBtn.setOnClickListener {
            if (screen.game.isTutorialsUtil.isTutorials) goBlock()
            btnList.onEach { it.disable() }
            screen.game.musicUtil.volumeLevelFlow.value /= 2
            screen.game.soundUtil.apply { play(SPINING) }

            coroutine?.launch {
                balanceFlow.value -= stakeList[stakeIndexFlow.value]
                if (slotGroup.spin()) {
                    screen.game.soundUtil.apply { play(WIN) }
                    balanceFlow.value += (stakeList[stakeIndexFlow.value] * APanelSettings.CURRENT_XxX.num)
                }
                runGDX { btnList.onEach { it.enable() } }
                screen.game.musicUtil.volumeLevelFlow.value *= 2
            }
        }
    }

}
