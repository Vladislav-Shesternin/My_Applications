package com.JindoBlu.game.screens

import com.JindoBlu.game.GDXGame
import com.JindoBlu.game.actors.ATutorials
import com.JindoBlu.game.actors.panel.APanelMenu
import com.JindoBlu.game.utils.*
import com.JindoBlu.game.utils.actor.*
import com.JindoBlu.game.utils.advanced.AdvancedScreen
import com.JindoBlu.game.utils.advanced.AdvancedStage
import kotlinx.coroutines.launch

class MenuScreen(override val game: GDXGame): AdvancedScreen() {

    private val panelMenu = APanelMenu(this).apply { color.a = 0f }
    private val tutorials = ATutorials(this).apply { color.a = 0f }

    override fun show() {
        setBackBackground(game.assetsLoader.MAIN_BACKGROUND.region)
        super.show()
    }

    override fun AdvancedStage.addActorsOnStageUI() {
        coroutine?.launch {
            runGDX {
                addPanel()
                if (game.isTutorialsUtil.isTutorials) addTutorials()
            }
            animShowPanelSuspend(panelMenu)
            if (game.isTutorialsUtil.isTutorials) tutorials.animShowSuspend(TIME_ANIM_SCREEN_ALPHA)
        }
    }

    override fun hideScreen(block: Block) {
        coroutine?.launch {
            if (game.isTutorialsUtil.isTutorials) tutorials.animHideSuspend(TIME_ANIM_SCREEN_ALPHA)
            animHidePanelSuspend(panelMenu) { block.invoke() }
        }
    }

    // Actors ------------------------------------------------------------------------

    private fun AdvancedStage.addPanel() {
        addAndFillActor(panelMenu)
        panelMenu.setPosition(-WIDTH_UI, HEIGHT_UI)

        val screenList = listOf(
            RulesScreen::class.java.name,
            GameScreen::class.java.name,
            SettingsScreen::class.java.name,
        )

        panelMenu.apply {
            btnList.onEachIndexed { index, btn ->
                btn.setOnClickListener(game.soundUtil) {
                    hideScreen {
                        if (game.isTutorialsUtil.isTutorials) ATutorials.nextStep()
                        game.navigationManager.navigate(screenList[index], MenuScreen::class.java.name)
                    }
                }
            }
            exitBtn.setOnClickListener { hideScreen { game.navigationManager.exit() } }
        }

    }

    private fun AdvancedStage.addTutorials() {
        addActor(tutorials)
        tutorials.setSize(WIDTH_UI, HEIGHT_UI)

        if (game.isTutorialsUtil.isTutorials) {
            when (ATutorials.STEP) {
                ATutorials.Static.Step.MenuBalance -> {
                    panelMenu.children.onEach { it.disable() }
                    tutorials.menuSettingsBlock = { panelMenu.btnList[2].enable() }
                }
                ATutorials.Static.Step.MenuRules -> {
                    panelMenu.children.onEach { it.disable() }
                    panelMenu.btnList[0].enable()
                }
                ATutorials.Static.Step.MenuGame -> {
                    panelMenu.children.onEach { it.disable() }
                    panelMenu.btnList[1].enable()
                }
                else -> {}
            }
        }
    }

}