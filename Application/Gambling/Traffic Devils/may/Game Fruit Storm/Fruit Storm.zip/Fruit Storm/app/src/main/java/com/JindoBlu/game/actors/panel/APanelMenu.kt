package com.JindoBlu.game.actors.panel

import com.JindoBlu.game.actors.autoLayout.AHorizontalGroup
import com.JindoBlu.game.actors.autoLayout.AVerticalGroup
import com.JindoBlu.game.actors.autoLayout.AutoLayout
import com.badlogic.gdx.scenes.scene2d.Actor
import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.badlogic.gdx.scenes.scene2d.ui.Label
import com.JindoBlu.game.actors.button.AButton
import com.JindoBlu.game.utils.GameColor
import com.JindoBlu.game.utils.advanced.AdvancedGroup
import com.JindoBlu.game.utils.advanced.AdvancedScreen
import com.JindoBlu.game.utils.font.FontParameter
import com.JindoBlu.game.utils.toBalanceFormat
import com.badlogic.gdx.graphics.Color

class APanelMenu(override val screen: AdvancedScreen): AdvancedGroup() {

    private val parameter = FontParameter().setCharacters(FontParameter.CharType.NUMBERS.chars+'.').setSize(50)
    private val font      = screen.fontGenerator_KronaOne.generateFont(parameter)

    val btnPanel   = Image(screen.game.assetsAll.MENU)
    val btnList    = List(3) { Actor() }
    val exitBtn    = AButton(screen, AButton.Static.Type.Exit)

    val horizontalGroup = AHorizontalGroup(screen, gap = 47f, startGap = 0f, endGap = 0f,
        alignmentH = AutoLayout.AlignmentHorizontal.CENTER,
        alignmentV = AutoLayout.AlignmentVertical.CENTER,
        direction = AHorizontalGroup.Static.Direction.RIGHT
    )
    val coinImg         = Image(screen.game.assetsAll.coin)
    val balanceLbl      = Label(screen.game.balanceUtil.balance.toBalanceFormat(), Label.LabelStyle(font, GameColor.white))


    override fun addActorsOnGroup() {
        addButtonPanel()
        addExit()
        addBalancePanel()
    }

    // Actors ------------------------------------------------------------------------
    private fun addButtonPanel() {
        addActor(btnPanel)
        btnPanel.setBounds(275f, 224f, 978f, 451f)

        // Rules
        btnList[0].apply {
            addActor(this)
            setBounds(396f, 380f, 140f, 140f)
        }
        // Game
        btnList[1].apply {
            addActor(this)
            setBounds(657f, 348f, 205f, 205f)
        }
        // Settings
        btnList[2].apply {
            addActor(this)
            setBounds(984f, 397f, 128f, 128f)
        }
    }

    private fun addExit() {
        addActor(exitBtn)
        exitBtn.setBounds(636f, 56f, 254f, 89f)
    }

    private fun addBalancePanel() {
        addActor(horizontalGroup)
        horizontalGroup.setBounds(391f, 745f, 745f, 98f)

        coinImg.setSize(116f, 98f)
        horizontalGroup.addActors(coinImg, balanceLbl)
    }

}