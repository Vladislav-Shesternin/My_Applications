package com.JindoBlu.game.manager.util

import com.JindoBlu.game.manager.SpriteManager
import com.badlogic.gdx.graphics.g2d.NinePatch
import com.badlogic.gdx.graphics.g2d.TextureRegion

class SpriteUtil {

     class Loader {
          val MAIN_BACKGROUND = SpriteManager.EnumTexture.MAIN_BACKGROUND.data.texture
     }

     class All {
          private fun getRegion(name: String): TextureRegion = SpriteManager.EnumAtlas.All.data.atlas.findRegion(name)
          private fun getPTH(name: String): NinePatch = SpriteManager.EnumAtlas.All.data.atlas.createPatch(name)

          val bacl_def        = getRegion("bacl_def")
          val bacl_press      = getRegion("bacl_press")
          val cb_def          = getRegion("cb_def")
          val cb_press        = getRegion("cb_press")
          val coin            = getRegion("coin")
          val exit_def        = getRegion("exit_def")
          val exit_press      = getRegion("exit_press")
          val glow            = getRegion("glow")
          val go_def          = getRegion("go_def")
          val go_dis          = getRegion("go_dis")
          val minus_def       = getRegion("minus_def")
          val minus_press     = getRegion("minus_press")
          val plus_def        = getRegion("plus_def")
          val plus_press      = getRegion("plus_press")
          val prog_background = getRegion("prog_background")
          val prog_progress   = getRegion("prog_progress")
          val click           = getRegion("click")
          val nxt_def         = getRegion("nxt_def")
          val nxt_press       = getRegion("nxt_press")

          val path            = getPTH("path")

          val items = List(11) { getRegion("${it.inc()}") }

          val BARABAN     = SpriteManager.EnumTexture.BARABAN.data.texture
          val MENU        = SpriteManager.EnumTexture.MENU.data.texture
          val MUSIC_SOUND = SpriteManager.EnumTexture.MUSIC_SOUND.data.texture
          val PROG_MASK   = SpriteManager.EnumTexture.PROG_MASK.data.texture
          val RULES       = SpriteManager.EnumTexture.RULES.data.texture

          val T_MUSIC = SpriteManager.EnumTexture.T_MUSIC.data.texture
          val T_SOUND = SpriteManager.EnumTexture.T_SOUND.data.texture
          val T_XXX   = SpriteManager.EnumTexture.T_XXX.data.texture
          val T_BACK  = SpriteManager.EnumTexture.T_BACK.data.texture

          val T_G_BALANCE = SpriteManager.EnumTexture.T_G_BALANCE.data.texture
          val T_G_GO      = SpriteManager.EnumTexture.T_G_GO.data.texture
          val T_G_STAKE   = SpriteManager.EnumTexture.T_G_STAKE.data.texture

     }

}