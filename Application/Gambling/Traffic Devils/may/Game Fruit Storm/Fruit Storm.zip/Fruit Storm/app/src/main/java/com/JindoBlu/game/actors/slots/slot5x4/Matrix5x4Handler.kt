package com.JindoBlu.game.actors.slots.slot5x4

import com.tdapps.test.game.actors.slots.SlotItem

class Matrix5x4Handler(
    private val matrix5x4        : Matrix5x4,
    private val slotItemContainer: SlotItemContainer
) {

    private val resultMatrix5x4 = matrix5x4.resultMatrix5x4

    private val slotA = listOf<Int>(matrix5x4.a1, matrix5x4.a2, matrix5x4.a3, matrix5x4.a4)
    private val slotB = listOf<Int>(matrix5x4.b1, matrix5x4.b2, matrix5x4.b3, matrix5x4.b4)
    private val slotC = listOf<Int>(matrix5x4.c1, matrix5x4.c2, matrix5x4.c3, matrix5x4.c4)
    private val slotD = listOf<Int>(matrix5x4.d1, matrix5x4.d2, matrix5x4.d3, matrix5x4.d4)
    private val slotE = listOf<Int>(matrix5x4.e1, matrix5x4.e2, matrix5x4.e3, matrix5x4.e4)

    private val glowA = listOf<Boolean>(resultMatrix5x4?.a1 ?: false, resultMatrix5x4?.a2 ?: false, resultMatrix5x4?.a3 ?: false, resultMatrix5x4?.a4 ?: false)
    private val glowB = listOf<Boolean>(resultMatrix5x4?.b1 ?: false, resultMatrix5x4?.b2 ?: false, resultMatrix5x4?.b3 ?: false, resultMatrix5x4?.b4 ?: false)
    private val glowC = listOf<Boolean>(resultMatrix5x4?.c1 ?: false, resultMatrix5x4?.c2 ?: false, resultMatrix5x4?.c3 ?: false, resultMatrix5x4?.c4 ?: false)
    private val glowD = listOf<Boolean>(resultMatrix5x4?.d1 ?: false, resultMatrix5x4?.d2 ?: false, resultMatrix5x4?.d3 ?: false, resultMatrix5x4?.d4 ?: false)
    private val glowE = listOf<Boolean>(resultMatrix5x4?.e1 ?: false, resultMatrix5x4?.e2 ?: false, resultMatrix5x4?.e3 ?: false, resultMatrix5x4?.e4 ?: false)

    private val slots = listOf(slotA, slotB, slotC, slotD, slotE)
    private val glows = listOf(glowA, glowB, glowC, glowD, glowE)

    private val shuffledSlotItemList = slotItemContainer.list.shuffled()

    fun generateSlot(slotIndex: Int): List<SlotItem> {
        val slotItemList = mutableListOf<SlotItem>()

        slots[slotIndex].onEach { slotItemIndex ->
            val slotItem = when (slotItemIndex) {
//                13   -> slotItemContainer.wild
                else -> shuffledSlotItemList[slotItemIndex]
            }
            slotItemList.add(slotItem)
        }

        return slotItemList
    }

    fun generateGlow(glowIndex: Int): List<Int> {
        val indexList = mutableListOf<Int>()
        glows[glowIndex].onEachIndexed { index, isWin -> if (isWin) indexList.add(index) }
        return indexList
    }

}