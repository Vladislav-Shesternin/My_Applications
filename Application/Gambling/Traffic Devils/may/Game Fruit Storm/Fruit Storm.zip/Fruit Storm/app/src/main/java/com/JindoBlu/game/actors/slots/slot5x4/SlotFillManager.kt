package com.JindoBlu.game.actors.slots.slot5x4

import com.JindoBlu.util.log
import com.tdapps.test.game.actors.slots.FillStrategy

class SlotFillManager(
    private val slotList: List<Slot>,
    private val glowList: List<Glow>,
    private val slotItemContainer: SlotItemContainer
) {

    private fun fillMix() {
        log("fillMix")

        val combinationMatrix5x4: ICombinationMatrix5x4 =
            Combination5x4.Mix //if (Random().nextBoolean()) Combination5x3.Mix else Combination5x3.MixWithWild
        val matrix5x4Handler = Matrix5x4Handler(combinationMatrix5x4.getMatrixAndLog(), slotItemContainer)

        slotList.onEachIndexed { index, slot -> slot.listSlotItemWin = matrix5x4Handler.generateSlot(index) }
    }

    private fun fillWin() {
        log("fillWin")

        val combinationMatrix5x4: ICombinationMatrix5x4 = Combination5x4.Win

//            listOf<CombinationMatrix5x3>(
//            Combination5x3.WinMonochrome,
//            Combination5x3.WinMonochromeWithWild,
//        ).shuffled().first()

        val matrix5x4Handler = Matrix5x4Handler(combinationMatrix5x4.getMatrixAndLog(), slotItemContainer)

        slotList.onEachIndexed { index, slot -> slot.listSlotItemWin = matrix5x4Handler.generateSlot(index) }
        glowList.onEachIndexed { index, glow -> glow.listIndexWin    = matrix5x4Handler.generateGlow(index) }
    }

    private fun ICombinationMatrix5x4.getMatrixAndLog(): Matrix5x4 {
        val matrix5x4Index = (0..matrixList.lastIndex).random()
        val matrix5x4      = matrixList[matrix5x4Index]
        log("CombinationMatrix5x4: ${this::class.java.name.substringAfterLast('$')} | ${matrix5x4Index.inc()}")

        return matrix5x4
    }

    fun fill(fillStrategy: FillStrategy) {
        when (fillStrategy) {
            FillStrategy.MIX -> fillMix()
            FillStrategy.WIN -> fillWin()
        }
    }

}