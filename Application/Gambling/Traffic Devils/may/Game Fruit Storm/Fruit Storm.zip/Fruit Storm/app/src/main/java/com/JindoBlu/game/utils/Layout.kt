package com.JindoBlu.game.utils

import com.badlogic.gdx.math.Vector2

object Layout {

    object Slot {
        val slot = LayoutData(0f, 0f, 142f, 142f, vs = 30f)
        val endY = -9614f
    }

    object Glow {
        val glow = LayoutData(0f, 0f, 229f, 229f, vs = -57f)
    }

    object SlotGroup {
        val slot = LayoutData(89f, 18f, 142f, 10290f, hs = 135f)
        val glow = LayoutData(45f, -25f, 229f, 745f, hs = 48f)
    }

    data class LayoutData(
        val x: Float = 0f,
        val y: Float = 0f,
        val w: Float = 0f,
        val h: Float = 0f,
        // horizontal space
        val hs: Float = 0f,
        // vertical space
        val vs: Float = 0f,
    ) {

        fun position() = Vector2(x, y)
        fun size() = Vector2(w, h)

    }

}












