package com.JindoBlu.game.actors.panel

import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.badlogic.gdx.scenes.scene2d.ui.Label
import com.JindoBlu.game.actors.AProgress
import com.JindoBlu.game.actors.button.AButton
import com.JindoBlu.game.actors.checkbox.ACheckBox
import com.JindoBlu.game.actors.checkbox.ACheckBoxGroup
import com.JindoBlu.game.utils.GameColor
import com.JindoBlu.game.utils.advanced.AdvancedGroup
import com.JindoBlu.game.utils.advanced.AdvancedScreen
import com.JindoBlu.game.utils.font.FontParameter
import com.JindoBlu.game.utils.runGDX
import kotlinx.coroutines.launch

class APanelSettings(override val screen: AdvancedScreen): AdvancedGroup() {

    companion object {
        var CURRENT_XxX = XxX.X2
    }

    private val parameter = FontParameter().setCharacters(FontParameter.CharType.NUMBERS.chars + "%x").setSize(30)
    private val font      = screen.fontGenerator_KronaOne.generateFont(parameter)

    val musicSoundImg = Image(screen.game.assetsAll.MUSIC_SOUND)
    val backBtn       = AButton(screen, AButton.Static.Type.Back)
    val musicProgress = AProgress(screen)
    val soundProgress = AProgress(screen)
    val musicLbl      = Label("", Label.LabelStyle(font, GameColor.white))
    val soundLbl      = Label("", Label.LabelStyle(font, GameColor.white))
    val cbList        = List(3) { ACheckBox(screen, ACheckBox.Static.Type.DEFAULT) }
    val xxList        = List(3) { Label(XxX.entries[it].str, Label.LabelStyle(font, GameColor.white)) }

    var onCheck_X3_Block = {}

    override fun addActorsOnGroup() {
        addMusicSound()
        addBack()
        addProgress()
        addPercentage()
        addCBList()
        addXXList()
    }

    // Actors ------------------------------------------------------------------------
    private fun addMusicSound() {
        addActor(musicSoundImg)
        musicSoundImg.setBounds(1168f, 190f, 260f, 581f)
    }

    private fun addBack() {
        addActor(backBtn)
        backBtn.setBounds(636f, 56f, 254f, 89f)
    }

    private fun addCBList() {
        val cbg = ACheckBoxGroup()
        var nx  = 345f
        cbList.onEachIndexed { index, box ->
            box.checkBoxGroup = cbg
            addActor(box)
            box.setBounds(nx, 436f, 88f, 88f)
            nx += 111 + 88

            box.setOnCheckListener {
                if (index == 1) onCheck_X3_Block()
                if (it) CURRENT_XxX = XxX.entries[index]
            }
        }

        when(CURRENT_XxX) {
            XxX.X2 -> cbList[0].check(false)
            XxX.X3 -> cbList[1].check(false)
            XxX.X4 -> cbList[2].check(false)
        }
    }

    private fun addXXList() {
        var nx = 445f
        xxList.onEach { box ->
            addActor(box)
            box.setBounds(nx, 461f, 45f, 38f)
            nx += 154 + 45
        }
    }

    private fun addProgress() {
        addActors(musicProgress, soundProgress)
        // Music
        musicProgress.apply {
            setBounds(124f, 608f, 953f, 66f)
            progressPercentFlow.value = screen.game.musicUtil.volumeLevelFlow.value

            coroutine?.launch {
                progressPercentFlow.collect {
                    runGDX {
                        musicLbl.setText("${it.toInt()}%")
                        screen.game.musicUtil.volumeLevelFlow.value = it
                    }
                }
            }
        }
        // Sound
        soundProgress.apply {
            setBounds(124f, 287f, 953f, 66f)
            progressPercentFlow.value = screen.game.soundUtil.volumeLevel

            coroutine?.launch {
                progressPercentFlow.collect {
                    runGDX {
                        soundLbl.setText("${it.toInt()}%")
                        screen.game.soundUtil.volumeLevel = it
                    }
                }
            }
        }
    }

    private fun addPercentage() {
        addActors(musicLbl, soundLbl)
        musicLbl.setBounds(903f, 614f, 168f, 54f)
        soundLbl.setBounds(903f, 293f, 168f, 54f)
    }



    enum class XxX(val str: String, val num: Int) {
        X2("x2", 2), X3("x3", 3), X4("x4", 4)
    }

}