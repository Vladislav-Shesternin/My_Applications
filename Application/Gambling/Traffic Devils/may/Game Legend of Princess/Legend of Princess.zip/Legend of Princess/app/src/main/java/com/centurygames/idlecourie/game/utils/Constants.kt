package com.centurygames.idlecourie.game.utils

const val WIDTH_UI  = 1080f
const val HEIGHT_UI = 1920f

const val Timek = 0.15f
