package com.centurygames.idlecourie.game.utils

import com.badlogic.gdx.graphics.Color

object HelloMotoColor {

    val blurik  = Color.valueOf("012570")

}