package com.bricks.vs.balls.game.box2d

object BodyId {
    const val NONE    = "none"
    const val BORDERS = "borders"
    const val BALL    = "ball"
    const val DYNAMIC = "dynamic"

}