package com.bricks.vs.balls.game.manager.util

import com.bricks.vs.balls.game.manager.ParticleEffectManager

class ParticleEffectUtil {

    val Boom = ParticleEffectManager.EnumParticleEffect.Boom.data.effect

}

