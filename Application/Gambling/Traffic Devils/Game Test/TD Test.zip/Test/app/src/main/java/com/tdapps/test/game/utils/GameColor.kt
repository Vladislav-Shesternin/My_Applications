package com.tdapps.test.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background = Color.valueOf("441D00")

}