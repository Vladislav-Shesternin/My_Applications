package com.hsr.bkm.mobile.game.utils

const val MAIN_ANIM_SPEED = 0.55f