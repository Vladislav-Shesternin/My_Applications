package plinko.games.mega.game.actors.checkbox

import com.boo.koftre.sure.game.game.actors.checkbox.ACheckBox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}