package com.boo.koftre.sure.game.game.actors

import com.boo.koftre.sure.game.game.utils.advanced.AdvancedGroup
import com.boo.koftre.sure.game.game.utils.advanced.AdvancedScreen

class TmpGroup(override val screen: AdvancedScreen): AdvancedGroup() {

    override fun addActorsOnGroup() {

    }

}