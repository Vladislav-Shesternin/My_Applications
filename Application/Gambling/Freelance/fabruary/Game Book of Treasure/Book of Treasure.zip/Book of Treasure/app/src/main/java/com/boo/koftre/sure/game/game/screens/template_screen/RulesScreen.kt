package com.boo.koftre.sure.game.game.screens.template_screen

import com.boo.koftre.sure.game.game.LibGDXGame
import com.boo.koftre.sure.game.game.screens.common.SettingsScreen
import com.boo.koftre.sure.game.game.utils.advanced.AdvancedStage

class RulesScreen(_game: LibGDXGame): ISuperScreen(_game, Static.TypeScreen.Rules) {

    override fun AdvancedStage.addActorsOnStage() {

    }

}