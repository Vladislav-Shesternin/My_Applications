package com.god.sof.olym.pus.game.box2d

object BodyId {
    const val NONE = "none"

    object Game {
        const val Oly = "game.tiger"

        val items = List(7) { "game.$it" }
    }
}