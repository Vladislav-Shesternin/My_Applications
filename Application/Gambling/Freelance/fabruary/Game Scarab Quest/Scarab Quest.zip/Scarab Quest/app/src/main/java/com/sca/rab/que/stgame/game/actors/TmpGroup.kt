package com.sca.rab.que.stgame.game.actors

import com.sca.rab.que.stgame.game.utils.advanced.AdvancedGroup
import com.sca.rab.que.stgame.game.utils.advanced.AdvancedScreen

class TmpGroup(override val screen: AdvancedScreen): AdvancedGroup() {

    override fun addActorsOnGroup() {

    }

}