package com.sca.rab.que.stgame.game.utils.puzzle

enum class PuzzleState {
    ASSEMBLED, NOT_ASSEMBLED
}