package com.phara.ohegy.ptgame.game.actors

import com.phara.ohegy.ptgame.game.utils.advanced.AdvancedGroup
import com.phara.ohegy.ptgame.game.utils.advanced.AdvancedScreen

class TmpGroup(override val screen: AdvancedScreen): AdvancedGroup() {

    override fun addActorsOnGroup() {

    }

}