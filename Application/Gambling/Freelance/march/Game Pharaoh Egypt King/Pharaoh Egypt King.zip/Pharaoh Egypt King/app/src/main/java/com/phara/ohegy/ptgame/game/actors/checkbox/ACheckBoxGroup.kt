package plinko.games.mega.game.actors.checkbox

import com.phara.ohegy.ptgame.game.actors.checkbox.ACheckBox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}