package com.phara.ohegy.ptgame.game.screens

import com.phara.ohegy.ptgame.game.LibGDXGame

class RulesScreen(ame: LibGDXGame) : IPanelScreen(ame, ScreenType.RULES)