package com.phara.ohegy.ptgame.game.utils

object GameColor {

//    val polublack:Color = Color.valueOf("333333")

}