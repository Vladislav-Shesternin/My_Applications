package com.egypt.tian.sto.game.game.actors

import com.egypt.tian.sto.game.game.utils.advanced.AdvancedGroup
import com.egypt.tian.sto.game.game.utils.advanced.AdvancedScreen

class TmpGroup(override val screen: AdvancedScreen): AdvancedGroup() {

    override fun addActorsOnGroup() {

    }

}