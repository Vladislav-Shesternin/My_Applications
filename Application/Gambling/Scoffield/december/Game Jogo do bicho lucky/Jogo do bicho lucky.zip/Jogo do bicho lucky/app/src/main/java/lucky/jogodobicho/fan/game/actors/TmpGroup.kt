package lucky.jogodobicho.fan.game.actors

import lucky.jogodobicho.fan.game.utils.advanced.AdvancedGroup
import lucky.jogodobicho.fan.game.utils.advanced.AdvancedScreen

class TmpGroup(override val screen: AdvancedScreen): AdvancedGroup() {

    override fun addActorsOnGroup() {

    }

}