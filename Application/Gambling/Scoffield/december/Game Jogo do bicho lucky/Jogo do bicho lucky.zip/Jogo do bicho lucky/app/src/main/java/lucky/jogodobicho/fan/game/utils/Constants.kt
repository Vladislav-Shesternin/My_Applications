package lucky.jogodobicho.fan.game.utils

const val WIDTH_UI     = 1080f
const val HEIGHT_UI    = 1920f

const val Time_ANIMATION = 0.5f