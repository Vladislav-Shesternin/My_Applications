package lucky.jogodobicho.fan.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val jelti:Color = Color.valueOf("FFE100")

}