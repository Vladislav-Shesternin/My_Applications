package rainbowriches.lucky.start.game.utils.puzzle

enum class PuzzleState {
    ASSEMBLED, NOT_ASSEMBLED
}