package rainbowriches.lucky.start.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val yellow:Color = Color.valueOf("FFE100")

}