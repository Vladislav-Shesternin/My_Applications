package fortune.tiger.avia.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val yellow:Color = Color.valueOf("FFE100")

}