package plinko.games.mega.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

//    val background:Color = Color.valueOf("0D0729")

}