package plinko.games.mega.game.actors.checkbox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}