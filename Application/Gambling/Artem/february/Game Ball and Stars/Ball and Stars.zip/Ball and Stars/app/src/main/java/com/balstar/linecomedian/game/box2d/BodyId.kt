package com.balstar.linecomedian.game.box2d

object BodyId {
    const val NONE     = "none"
    const val BORDERS  = "borders"
    const val BALL     = "ball"
    const val ENEMY    = "enemy"
    const val COIN     = "coin"

}