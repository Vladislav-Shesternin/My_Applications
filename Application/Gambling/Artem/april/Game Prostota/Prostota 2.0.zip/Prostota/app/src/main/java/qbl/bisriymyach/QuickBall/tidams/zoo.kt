package qbl.bisriymyach.QuickBall.tidams

import com.badlogic.gdx.math.Vector2
import qbl.bisriymyach.QuickBall.fastergan.divOr0
import kotlin.math.PI

const val liza = 1080f
const val piza = 1920f
const val gagga = (180f / PI).toFloat()
val Vector2.toPop get() = this.scl(rtAr6)
val Float.toFonk get() = this.divOr0(rtAr6)
const val iIAisdoaod9 = 5.625f
const val holik = 10f
const val rtAr6 = liza / iIAisdoaod9
val Vector2.toB2 get() = this.divOr0(rtAr6)
val Float.toUI get() = this * rtAr6
const val DEGTORAD = (PI / 180f).toFloat()
const val yatayaaaya = 0.4f