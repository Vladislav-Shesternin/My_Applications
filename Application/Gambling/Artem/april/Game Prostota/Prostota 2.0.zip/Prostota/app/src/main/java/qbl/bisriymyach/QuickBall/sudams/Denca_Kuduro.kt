package qbl.bisriymyach.QuickBall.sudams

import qbl.bisriymyach.QuickBall.pipRen

class Denca_Kuduro {
    var currentCheckedCheckBox: pipRen? = null
}