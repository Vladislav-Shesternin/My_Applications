package qbl.bisriymyach.QuickBall.hotvils

object Omred {
    const val NONE      = "none"

    const val STATIC = "static"
    const val BALL   = "ball"

    const val x01 = "0.1"
    const val x05 = "0.5"
    const val x15 = "1.5"
    const val x10 = "10"
}