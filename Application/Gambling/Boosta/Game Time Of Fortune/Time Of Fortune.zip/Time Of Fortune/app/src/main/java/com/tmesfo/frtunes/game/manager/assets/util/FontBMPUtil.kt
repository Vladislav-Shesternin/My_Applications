package com.tmesfo.frtunes.game.manager.assets.util

object FontBMPUtil {

//    val FONT: FontBMPManager.IFont get() = when(Language.locale.language) {
//        else -> FontBMPManager.GoldFont
//    }

}