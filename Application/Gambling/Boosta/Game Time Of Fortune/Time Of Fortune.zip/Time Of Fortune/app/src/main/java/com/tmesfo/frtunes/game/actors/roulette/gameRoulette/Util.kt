package com.tmesfo.frtunes.game.actors.roulette.gameRoulette

//data class SuperGameRouletteItem(
//    override val segment: Pair<Float, Float>,
//    val number          : Int,
//): RouletteGroupController.RouletteItem