package com.tmesfo.frtunes.game.actors.label.scrolling

import com.tmesfo.frtunes.game.utils.controller.GroupController

class ScrollingLabelController(override val group: ScrollingLabel) : GroupController {
}