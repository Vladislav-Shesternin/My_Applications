package com.tmesfo.frtunes.game.utils

const val WIDTH = 700f
const val HEIGHT = 1400f