package com.tmesfo.frtunes.game.screens.menu

import com.tmesfo.frtunes.game.utils.controller.ScreenController

class MenuScreenController(
    override val screen: MenuScreen
) : ScreenController {

}