package com.tmesfo.frtunes.game.utils.controller

import com.tmesfo.frtunes.game.advanced.group.AbstractAdvancedGroup

interface GroupController {
    val group: AbstractAdvancedGroup
}