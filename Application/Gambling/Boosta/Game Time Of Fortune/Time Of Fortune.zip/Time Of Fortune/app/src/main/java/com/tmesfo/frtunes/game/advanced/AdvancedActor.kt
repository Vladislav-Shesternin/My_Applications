package com.tmesfo.frtunes.game.advanced

import com.badlogic.gdx.scenes.scene2d.ui.Widget
import com.badlogic.gdx.utils.Disposable

open class AdvancedActor : Widget(), Disposable {

    override fun dispose() {}

}