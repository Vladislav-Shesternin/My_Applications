package com.tmesfo.frtunes.game.actors.checkbox

class CheckBoxGroup {
    var currentCheckedCheckBox: CheckBox? = null
}