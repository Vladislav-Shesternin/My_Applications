package com.tmesfo.frtunes.game.utils.controller

import com.tmesfo.frtunes.game.advanced.AdvancedScreen

interface ScreenController {
    val screen: AdvancedScreen
}