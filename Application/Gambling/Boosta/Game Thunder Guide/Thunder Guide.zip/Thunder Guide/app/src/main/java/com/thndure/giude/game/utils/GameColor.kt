package com.thndure.giude.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background = Color.valueOf("2A003E")
    val text       = Color.valueOf("FFF4A8")

}