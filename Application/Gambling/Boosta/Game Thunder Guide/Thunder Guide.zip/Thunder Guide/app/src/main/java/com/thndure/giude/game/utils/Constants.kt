package com.thndure.giude.game.utils

const val WIDTH_UI     = 1422f
const val HEIGHT_UI    = 824f

const val TIME_ANIM_SCREEN_ALPHA = 0.4f