package com.rcks.scaloi.game.actors.checkbox

class CheckBoxGroup {
    var currentCheckedCheckBox: CheckBox? = null
}