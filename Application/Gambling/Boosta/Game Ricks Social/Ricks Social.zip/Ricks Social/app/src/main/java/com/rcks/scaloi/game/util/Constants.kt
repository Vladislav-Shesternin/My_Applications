package com.rcks.scaloi.game.util

const val WIDTH = 1920f
const val HEIGHT = 1080f