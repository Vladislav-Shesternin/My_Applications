package com.rcks.scaloi.game.util

import com.badlogic.gdx.InputMultiplexer
import com.badlogic.gdx.InputProcessor
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.Batch
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.badlogic.gdx.math.Vector2
import com.badlogic.gdx.scenes.scene2d.Actor
import com.badlogic.gdx.scenes.scene2d.Touchable
import com.badlogic.gdx.scenes.scene2d.ui.Widget
import com.badlogic.gdx.scenes.scene2d.ui.WidgetGroup
import com.badlogic.gdx.utils.Disposable
import com.badlogic.gdx.utils.viewport.Viewport
import com.rcks.scaloi.util.length
import com.badlogic.gdx.Gdx

val Texture.region: TextureRegion get() = TextureRegion(this)

val Viewport.zeroScreenVector: Vector2 get() = project(Vector2(0f, 0f))



fun disposeAll(vararg disposable: Disposable) {
    disposable.forEach { it.dispose() }
}

fun Batch.beginend(block: Batch.() -> Unit = { }) {
    begin()
    block()
    end()
}

fun Batch.endbegin(block: Batch.() -> Unit = { }) {
    end()
    block()
    begin()
}

fun runGDX(block: () -> Unit) {
    Gdx.app.postRunnable { block() }
}

fun InputMultiplexer.addProcessors(vararg processor: InputProcessor) {
    processor.onEach { addProcessor(it) }
}

fun Actor.disable() {
    touchable = Touchable.disabled
}

fun Actor.enable() {
    touchable = Touchable.enabled
}

fun List<Actor>.setFillParent() {
    onEach { actor ->
        when (actor) {
            is Widget      -> actor.setFillParent(true)
            is WidgetGroup -> actor.setFillParent(true)
        }
    }
}


fun Long.transformToBalanceFormat(): String {
    val balance = toString().toMutableList()

    when (length) {
        4    -> balance.add(1, ' ')
        5    -> balance.add(2, ' ')
        6    -> balance.add(3, ' ')
        7    -> {
            balance.add(1, ' ')
            balance.add(5, ' ')
        }
        8    -> {
            balance.add(2, ' ')
            balance.add(6, ' ')
        }
        9    -> {
            balance.add(3, ' ')
            balance.add(7, ' ')
        }
        10   -> {
            balance.add(1, ' ')
            balance.add(5, ' ')
            balance.add(9, ' ')
        }
        11   -> {
            balance.add(2, ' ')
            balance.add(6, ' ')
            balance.add(10, ' ')
        }
        12   -> {
            balance.add(3, ' ')
            balance.add(7, ' ')
            balance.add(11, ' ')
        }
        else -> toString()
    }

    return balance.joinToString("")
}

enum class AutospinState {
    DEFAULT, GO,
}