package com.bezdrodovam.cryptoinsightspro.game.actors.checkbox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}