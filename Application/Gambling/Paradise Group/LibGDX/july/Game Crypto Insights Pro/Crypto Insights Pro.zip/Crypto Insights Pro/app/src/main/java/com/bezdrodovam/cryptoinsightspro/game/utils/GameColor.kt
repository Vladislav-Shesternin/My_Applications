package com.bezdrodovam.cryptoinsightspro.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {
    val puplik  = Color.valueOf("261E35")
    val grinkin = Color.valueOf("46FF28")
    val grankid = Color.valueOf("535353")
    val gfggfg  = Color.valueOf("818181")
}