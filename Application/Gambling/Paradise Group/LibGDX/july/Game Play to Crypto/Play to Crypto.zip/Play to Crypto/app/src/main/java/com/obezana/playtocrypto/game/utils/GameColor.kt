package com.obezana.playtocrypto.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val black = Color.valueOf("373737")

}