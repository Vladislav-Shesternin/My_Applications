package com.obezana.playtocrypto.game.box2d

object BodyId {
    const val NONE = "none"

    object Menu {
        const val STATIC = "menu.static"
        const val BUTTON = "menu.button"
    }
}