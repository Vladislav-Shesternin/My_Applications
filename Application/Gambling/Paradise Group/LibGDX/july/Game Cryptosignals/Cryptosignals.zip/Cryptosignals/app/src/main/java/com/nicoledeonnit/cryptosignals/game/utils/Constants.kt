package com.nicoledeonnit.cryptosignals.game.utils

const val WIDTH : Float = 878f
const val HEIGHT: Float = 1759f