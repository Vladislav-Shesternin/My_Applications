package com.nicoledeonnit.cryptosignals.game.utils

import com.badlogic.gdx.graphics.Color

object Stepan {
    val giga  = Color.valueOf("04DC00")
}