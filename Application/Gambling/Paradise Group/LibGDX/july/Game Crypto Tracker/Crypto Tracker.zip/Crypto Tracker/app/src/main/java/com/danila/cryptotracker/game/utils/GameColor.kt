package com.danila.cryptotracker.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {
    val lobodaHUINA  = Color.valueOf("B2FF34")
    val gagillaGlasa = Color.valueOf("3F845F")
}