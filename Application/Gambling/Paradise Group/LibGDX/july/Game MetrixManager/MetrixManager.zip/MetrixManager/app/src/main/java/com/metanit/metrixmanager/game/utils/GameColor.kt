package com.metanit.metrixmanager.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {
    val orda  = Color.valueOf("F8AC49")
}