package com.metanit.metrixmanager.game.utils

const val WIDTH : Float = 704f
const val HEIGHT: Float = 1526f