package com.prochenkoa.businessplanner.game.utils

const val WIDTH : Float = 739f
const val HEIGHT: Float = 1643f