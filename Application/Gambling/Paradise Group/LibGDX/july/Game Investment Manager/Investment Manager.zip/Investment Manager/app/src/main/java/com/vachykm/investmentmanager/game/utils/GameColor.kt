package com.vachykm.investmentmanager.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {
    val purple = Color.valueOf("3C115F")
    val red    = Color.valueOf("FF0000")
    val green  = Color.valueOf("66DC43")
    val puple  = Color.valueOf("2A2827")
}