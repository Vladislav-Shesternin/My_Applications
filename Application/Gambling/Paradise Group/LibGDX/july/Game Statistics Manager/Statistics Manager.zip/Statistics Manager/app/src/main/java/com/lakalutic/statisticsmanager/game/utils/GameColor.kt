package com.lakalutic.statisticsmanager.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {
    val seriy  = Color.valueOf("F1F2F3")
    val sirik  = Color.valueOf("4E505F")
}