package com.lakalutic.statisticsmanager.game.utils

const val WIDTH : Float = 773f
const val HEIGHT: Float = 1673f