package com.leto.advancedcalculator.game.utils

const val WIDTH : Float = 783f
const val HEIGHT: Float = 1670f