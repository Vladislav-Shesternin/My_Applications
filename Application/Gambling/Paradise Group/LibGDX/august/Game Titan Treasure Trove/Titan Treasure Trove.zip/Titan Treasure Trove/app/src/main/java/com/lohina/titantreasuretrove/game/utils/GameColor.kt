package com.lohina.titantreasuretrove.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background = Color.valueOf("FF70B6")
    val pirple     = Color.valueOf("7565CF")

}