package com.zaykoa.investmentanalyzer.util

import com.onesignal.OneSignal
import com.zaykoa.investmentanalyzer.appContext

object OneSignalUtil {

    private const val ONESIGNAL_APP_ID = "f2553be8-efd1-4407-a6ea-303c9d7a5a03"

    fun initialize() {
        log("OneSignal initialize")

        OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
        OneSignal.initWithContext(appContext)
        OneSignal.setAppId(ONESIGNAL_APP_ID)
    }

}