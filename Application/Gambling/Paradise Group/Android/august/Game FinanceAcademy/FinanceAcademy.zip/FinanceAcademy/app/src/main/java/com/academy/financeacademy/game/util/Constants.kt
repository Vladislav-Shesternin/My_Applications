package com.academy.financeacademy.game.util

//val DENSITY by lazy { appContext.resources.displayMetrics.density.toInt() }

const val WIDTH_UI  = 603f
const val HEIGHT_UI = 1306f