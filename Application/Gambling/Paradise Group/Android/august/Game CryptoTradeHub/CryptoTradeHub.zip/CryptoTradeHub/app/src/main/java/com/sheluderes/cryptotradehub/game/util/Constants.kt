package com.sheluderes.cryptotradehub.game.util

//val DENSITY by lazy { appContext.resources.displayMetrics.density.toInt() }

const val WIDTH_UI  = 680f
const val HEIGHT_UI = 1472f