package com.logic.exchangewizard.game.util

//val DENSITY by lazy { appContext.resources.displayMetrics.density.toInt() }

const val WIDTH_UI  = 629f
const val HEIGHT_UI = 1399f