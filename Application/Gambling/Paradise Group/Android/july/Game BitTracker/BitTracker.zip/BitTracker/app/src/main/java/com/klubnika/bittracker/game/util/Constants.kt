package com.klubnika.bittracker.game.util

//val DENSITY by lazy { appContext.resources.displayMetrics.density.toInt() }

const val WIDTH_UI  = 555f
const val HEIGHT_UI = 1233f