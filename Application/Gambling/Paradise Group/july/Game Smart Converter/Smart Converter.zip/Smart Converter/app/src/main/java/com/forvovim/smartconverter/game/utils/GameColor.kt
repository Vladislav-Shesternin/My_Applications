package com.forvovim.smartconverter.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {
    val gadaBlaCKAaa  = Color.valueOf("535353")
    val GrttaA  = Color.valueOf("878787")
    val Sdod  = Color.valueOf("4BEC00")
    val lodsdf  = Color.valueOf("FF3131")
}