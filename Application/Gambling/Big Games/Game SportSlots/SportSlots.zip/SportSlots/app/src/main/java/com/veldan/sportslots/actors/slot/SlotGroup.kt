package com.veldan.sportslots.actors.slot

import com.badlogic.gdx.math.Rectangle
import com.badlogic.gdx.scenes.scene2d.actions.Actions
import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.badlogic.gdx.utils.viewport.Viewport
import com.veldan.sportslots.actors.ScissorGroup
import com.veldan.sportslots.advanced.AdvancedGroup
import com.veldan.sportslots.assets.SpriteManager
import com.veldan.sportslots.utils.*
import com.veldan.sportslots.utils.slot.SlotItem
import com.veldan.sportslots.utils.slot.SlotManager
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

class SlotGroup(viewport: Viewport) : AdvancedGroup() {

    companion object {
        private var WIN_NUMBER = Random.nextInt(1, 5)
        const val DELAY_BETWEEN_SPIN = 1000L
    }

    private var spinCounter = 0

    private val slotSeparator = Image(SpriteManager.GameSprite.SLOT_SEPARATOR.textureData.texture)
    private val slotList = List(3) { Slot() }
    private val glowList = List(3) { Image(SpriteManager.GameSprite.GLOW.textureData.texture) }
    private val winLineList = List(3) { Image(SpriteManager.GameSprite.LINE_WIN.textureData.texture) }
    private val scissorGroup = ScissorGroup(
        viewport,
        Rectangle(SCISSOR_X, getFigmaY(SCISSOR_Y, SCISSOR_H), SCISSOR_W, SCISSOR_H)
    )

    private val slotManager = SlotManager(*slotList.toTypedArray())



    init {
        addActorsOnGroup()
    }



    private fun addActorsOnGroup() {
        addSlotGroupPanel()
        addGlows()
        addSlots()
        addSlotSeparator()
        addWinLines()
    }

    private fun addSlotGroupPanel() {
        val image = Image(SpriteManager.GameSprite.SLOT_GROUP_PANEL.textureData.texture).apply {
            setBoundsFigmaY(SLOT_GROUP_PANEL_X, SLOT_GROUP_PANEL_Y, SLOT_GROUP_PANEL_W, SLOT_GROUP_PANEL_H)
        }
        addActor(image)
    }

    private fun addGlows() {
        var newY = GLOW_FIRST_Y
        glowList.onEach {
            it.addAction(Actions.alpha(0f))
            it.setBoundsFigmaY(GLOW_X, newY, GLOW_W, GLOW_H)
            newY += it.height + GLOW_SPACE_VERTICAL
            addActor(it)
        }
    }

    private fun addSlots() {
        var newX = SLOT_FIRST_X
        slotList.onEach {
            it.setBoundsFigmaY(newX, SLOT_START_Y, SLOT_W, SLOT_H)
            newX += it.width + SLOT_SPACE_HORIZONTAL
            scissorGroup.addActor(it)
        }
        addActor(scissorGroup.group)
    }
    
    private fun addSlotSeparator() {
        val image = slotSeparator.apply {
            setBoundsFigmaY(SLOT_SEPARATOR_X, SLOT_SEPARATOR_Y, SLOT_SEPARATOR_W, SLOT_SEPARATOR_H)
        }
        addActor(image)
    }

    private fun addWinLines() {
        var newY = WIN_LINE_FIRST_Y
        winLineList.onEach {
            it.setBoundsFigmaY(WIN_LINE_START_X, newY, WIN_LINE_W, WIN_LINE_H)
            newY += it.height + WIN_LINE_SPACE_VERTICAL
            scissorGroup.addActor(it)
        }
    }



    private fun checkWin(): List<SlotItem> {
        val winList = mutableListOf<SlotItem>()

        slotList.first().listItemWin.onEachIndexed { indexSlotItem, slotItem ->
            val resultList = mutableListOf<Boolean>()
            (1..slotList.lastIndex).onEach { indexSlot ->
                val result = (slotItem.id == slotList[indexSlot].listItemWin[indexSlotItem].id)
                resultList.add(result)
            }
            if (resultList.all { it }) {
                showWin(indexSlotItem)
                winList.add(slotItem)
            }
        }
        return winList
    }

    private fun showWin(row: Int) {
        log("WIN ROW: $row")
        slotSeparator.addAction(Actions.fadeOut(1f))
        glowList[row].addAction(Actions.fadeIn(1f))
        winLineList[row].addAction(Actions.moveTo(WIN_LINE_END_X, winLineList[row].y, 1f))
    }

    private fun resetWin() {
        spinCounter = 0
        WIN_NUMBER = Random.nextInt(1, 5)
    }

    suspend fun spin() = coroutineScope {
        glowList.onEach { it.addAction(Actions.fadeOut(1f)) }
        winLineList.onEach { it.addAction(Actions.moveTo(WIN_LINE_START_X, it.y, 1f)) }
        slotSeparator.addAction(Actions.fadeIn(1f))
        spinCounter++
        log("WIN NUM = $WIN_NUMBER ||| spinCount = $spinCounter")
        if (spinCounter == WIN_NUMBER) {
            log("fill WIN")
            slotManager.fill(SlotManager.Strategy.WIN)
        } else {
            log("fill RANDOM")
            slotManager.fill(SlotManager.Strategy.RANDOM)
        }

        slotList.onEach {
            launch { it.spin() }
            delay(DELAY_BETWEEN_SPIN)
        }
        delay(Slot.DELAY_SPIN - DELAY_BETWEEN_SPIN)

        log("FINISH SPIN")
        checkWin().apply { if (isNotEmpty()) resetWin() }
    }

}