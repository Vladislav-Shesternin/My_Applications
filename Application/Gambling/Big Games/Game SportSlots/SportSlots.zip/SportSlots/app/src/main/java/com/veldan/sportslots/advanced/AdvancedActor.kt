package com.veldan.sportslots.advanced

import com.badlogic.gdx.scenes.scene2d.Actor
import com.badlogic.gdx.utils.Disposable

open class AdvancedActor : Actor(), Disposable {

    override fun dispose() {}

}