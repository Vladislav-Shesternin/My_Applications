package com.veldan.sportslots

const val WIDTH = 700f
const val HEIGHT = 1400f