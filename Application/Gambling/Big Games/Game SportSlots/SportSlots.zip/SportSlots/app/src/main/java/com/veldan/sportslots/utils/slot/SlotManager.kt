package com.veldan.sportslots.utils.slot

import com.veldan.sportslots.actors.slot.Slot
import com.veldan.sportslots.assets.SpriteManager
import com.veldan.sportslots.utils.slot.SlotManager.Strategy.*
import kotlin.random.Random

class SlotManager(
     vararg val slots: Slot
) {

    private val itemList = listOf<SlotItem>(
       SlotItem(0, 1500, SpriteManager.GameSpriteList.ITEM_LIST.textureDataList[0].texture),
       SlotItem(1, 2000, SpriteManager.GameSpriteList.ITEM_LIST.textureDataList[1].texture),
       SlotItem(2, 5000, SpriteManager.GameSpriteList.ITEM_LIST.textureDataList[2].texture),
       SlotItem(3, 7000, SpriteManager.GameSpriteList.ITEM_LIST.textureDataList[3].texture),
       SlotItem(4, 9500, SpriteManager.GameSpriteList.ITEM_LIST.textureDataList[4].texture),
       SlotItem(5, 12000, SpriteManager.GameSpriteList.ITEM_LIST.textureDataList[5].texture),
       SlotItem(6, 15000, SpriteManager.GameSpriteList.ITEM_LIST.textureDataList[6].texture),
       SlotItem(7, 17000, SpriteManager.GameSpriteList.ITEM_LIST.textureDataList[7].texture),
    )

    private var listWinItem = mutableListOf<SlotItem>()



    fun fill(strategy: Strategy) {
        when (strategy) {
            WIN    -> {
                val row = Random.nextInt(0, 2)
                val item = itemList.random()
                slots.onEach {  slot ->
                    listWinItem = MutableList(3) { itemList.random() }
                    listWinItem[row] = item
                    slot.setWin(listWinItem)
                }
            }
            RANDOM -> {
                slots.onEach { slot ->
                    listWinItem = mutableListOf()
                    repeat(3) { listWinItem.add(itemList.random()) }
                    slot.setWin(listWinItem)
                }
            }
        }
    }



    enum class Strategy{
        RANDOM, WIN
    }

}