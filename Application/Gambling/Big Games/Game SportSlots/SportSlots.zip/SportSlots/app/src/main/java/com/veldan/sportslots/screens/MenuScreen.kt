package com.veldan.sportslots.screens

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.g2d.Batch
import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.badlogic.gdx.utils.viewport.FitViewport
import com.veldan.sportslots.HEIGHT
import com.veldan.sportslots.WIDTH
import com.veldan.sportslots.actors.ButtonClickable
import com.veldan.sportslots.advanced.AdvancedGroup
import com.veldan.sportslots.advanced.AdvancedScreen
import com.veldan.sportslots.advanced.AdvancedStage
import com.veldan.sportslots.assets.SpriteManager
import com.veldan.sportslots.utils.*
import com.veldan.sportslots.utils.NavigationUtil
import com.veldan.sportslots.utils.setBoundsFigmaY

class MenuScreen : AdvancedScreen() {
    override val viewport = FitViewport(WIDTH, HEIGHT)



    override fun show() {
        super.show()
        stage.addActorsOnStage()
    }

    private fun AdvancedStage.addActorsOnStage(){
        addButtonPanel()
        addPlay()
        addExit()
    }



    private fun AdvancedStage.addButtonPanel(){
        val image = Image(SpriteManager.MenuSprite.BUTTON_PANEL.textureData.texture).apply {
            setBoundsFigmaY(BUTTON_PANEL_X, BUTTON_PANEL_Y, BUTTON_PANEL_W, BUTTON_PANEL_H)
        }
        addActor(image)
    }

    private fun AdvancedStage.addPlay(){
        val button = ButtonClickable(ButtonClickable.Style(
            default = SpriteManager.MenuSprite.PLAY_DEF.textureData.texture,
            pressed = SpriteManager.MenuSprite.PLAY_PRESS.textureData.texture,
        )).apply { 
            setBoundsFigmaY(PLAY_X, PLAY_Y, PLAY_W, PLAY_H)
            setOnClickListener { playHandler() }
        }
        addActor(button)
    }

    private fun AdvancedStage.addExit() {
        val button = ButtonClickable(ButtonClickable.Style(
            default = SpriteManager.MenuSprite.EXIT_DEF.textureData.texture,
            pressed = SpriteManager.MenuSprite.EXIT_PRESS.textureData.texture,
        )).apply {
            setBoundsFigmaY(EXIT_X, EXIT_Y, EXIT_W, EXIT_H)
            setOnClickListener { exitHandler() }
        }
        addActor(button)
    }



    private fun ButtonClickable.playHandler() {
        NavigationUtil.navigate(GameScreen(), MenuScreen())
    }

    private fun ButtonClickable.exitHandler() {
        NavigationUtil.exit()
    }
    
}