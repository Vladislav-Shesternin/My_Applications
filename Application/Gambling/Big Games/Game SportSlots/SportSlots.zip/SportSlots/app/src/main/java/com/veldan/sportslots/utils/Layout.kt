package com.veldan.sportslots.utils

// ------------------------------------------------------------------------
// Menu
// ------------------------------------------------------------------------

const val BUTTON_PANEL_X = -65f
const val BUTTON_PANEL_Y = 108f
const val BUTTON_PANEL_W = 810f
const val BUTTON_PANEL_H = 984f

const val PLAY_X = 148f
const val PLAY_Y = 555f
const val PLAY_W = 404f
const val PLAY_H = 123f

const val EXIT_X = 148f
const val EXIT_Y = 723f
const val EXIT_W = 404f
const val EXIT_H = 123f

// ------------------------------------------------------------------------
// Game
// ------------------------------------------------------------------------

const val BALANCE_PANEL_X = 178f
const val BALANCE_PANEL_Y = 88f
const val BALANCE_PANEL_W = 339f
const val BALANCE_PANEL_H = 50f

const val BALANCE_TEXT_X = 234f
const val BALANCE_TEXT_Y = 92f
const val BALANCE_TEXT_W = 275f
const val BALANCE_TEXT_H = 41f

const val MENU_X = 586f
const val MENU_Y = 88f
const val MENU_W = 63f
const val MENU_H = 50f

const val COLLECTION_X = 51f
const val COLLECTION_Y = 88f
const val COLLECTION_W = 67f
const val COLLECTION_H = 50f

const val SPIN_X = 148f
const val SPIN_Y = 1084f
const val SPIN_W = 404f
const val SPIN_H = 123f

const val SLOT_ITEM_SPACE_VERTICAL = 30f
const val SLOT_ITEM_W = 182f
const val SLOT_ITEM_H = 182f

const val SLOT_START_Y = -20289f
const val SLOT_END_Y = 275f
const val SLOT_FIRST_X = 57f
const val SLOT_W = 182f
const val SLOT_H = 21170f
const val SLOT_SPACE_HORIZONTAL = 20f

const val SLOT_GROUP_PANEL_X = -65f
const val SLOT_GROUP_PANEL_Y = 108f
const val SLOT_GROUP_PANEL_W = 810f
const val SLOT_GROUP_PANEL_H = 984f

const val SCISSOR_X = 59f
const val SCISSOR_Y = 284f
const val SCISSOR_W = 582f
const val SCISSOR_H = 608f

const val SLOT_SEPARATOR_X = 243f
const val SLOT_SEPARATOR_Y = 369f
const val SLOT_SEPARATOR_W = 216f
const val SLOT_SEPARATOR_H = 413f

const val GLOW_FIRST_Y = 172f
const val GLOW_X = -48f
const val GLOW_W = 792f
const val GLOW_H = 391f
const val GLOW_SPACE_VERTICAL = -180f

const val WIN_LINE_FIRST_Y = 340f
const val WIN_LINE_START_X = -531f
const val WIN_LINE_END_X = 61f
const val WIN_LINE_W = 579f
const val WIN_LINE_H = 43f
const val WIN_LINE_SPACE_VERTICAL = 172f

// ------------------------------------------------------------------------
// Collection
// ------------------------------------------------------------------------

const val COIN_X = 0f
const val COIN_Y = 61f
const val COIN_W = 165f
const val COIN_H = 137f

const val BACK_X = 148f
const val BACK_Y = 1084f
const val BACK_W = 404f
const val BACK_H = 123f

const val LEFT_X = 0f
const val LEFT_Y = 1082f
const val LEFT_W = 123f
const val LEFT_H = 123f

const val RIGHT_X = 577f
const val RIGHT_Y = 1082f
const val RIGHT_W = 123f
const val RIGHT_H = 123f

const val STAND_X = 73f
const val STAND_Y = 700f
const val STAND_W = 554f
const val STAND_H = 359f

const val PRICE_X = 190f
const val PRICE_Y = 87f
const val PRICE_W = 320f
const val PRICE_H = 87f

const val ITEM_X = 44f
const val ITEM_Y = 108f
const val ITEM_W = 613f
const val ITEM_H = 793f






