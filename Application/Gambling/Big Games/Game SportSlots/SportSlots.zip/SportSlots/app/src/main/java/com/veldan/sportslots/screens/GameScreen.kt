package com.veldan.sportslots.screens

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.badlogic.gdx.scenes.scene2d.ui.Label
import com.badlogic.gdx.utils.Align
import com.badlogic.gdx.utils.viewport.FitViewport
import com.veldan.sportslots.HEIGHT
import com.veldan.sportslots.WIDTH
import com.veldan.sportslots.actors.ButtonClickable
import com.veldan.sportslots.actors.slot.SlotGroup
import com.veldan.sportslots.advanced.AdvancedScreen
import com.veldan.sportslots.advanced.AdvancedStage
import com.veldan.sportslots.assets.FontManager
import com.veldan.sportslots.assets.SpriteManager
import com.veldan.sportslots.utils.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class GameScreen: AdvancedScreen() {
    override val viewport = FitViewport(WIDTH, HEIGHT)

    private val coroutineSpin = CoroutineScope(Dispatchers.Main)
    private val coroutineBalance = CoroutineScope(Dispatchers.IO)

    private val slotGroup = SlotGroup(viewport)
    private val balanceText = Label("", Label.LabelStyle(FontManager.rubik_33, Color(13f / 255, 0f, 73f / 255, 1f)))


    override fun show() {
        super.show()
        stage.addActorsOnStage()
    }

    override fun dispose() {
        super.dispose()
        cancelCoroutinesAll(coroutineSpin, coroutineBalance)
    }



    private fun AdvancedStage.addActorsOnStage(){
        addSlotGroup()
        addBalancePanel()
        addBalanceText()
        addMenu()
        addCollection()
        addSpin()
    }
    
    private fun AdvancedStage.addBalancePanel() {
        val image = Image(SpriteManager.GameSprite.BALANCE_PANEL.textureData.texture).apply {
            setBoundsFigmaY(BALANCE_PANEL_X, BALANCE_PANEL_Y, BALANCE_PANEL_W, BALANCE_PANEL_H)
        }
        addActor(image)
    }

    private fun AdvancedStage.addBalanceText(){
        val text = balanceText.apply {
            setBoundsFigmaY(BALANCE_TEXT_X, BALANCE_TEXT_Y, BALANCE_TEXT_W, BALANCE_TEXT_H)
            setAlignment(Align.center)
            wrap = true

            coroutineBalance.launch {
                DataStoreUtil.collectPrice {
                    log("PRICE = $it")
                    setText(it)
                }
            }
        }
        addActor(text)
    }

    private fun AdvancedStage.addMenu(){
        val button = ButtonClickable(ButtonClickable.Style(
            default = SpriteManager.GameSprite.MENU_DEF.textureData.texture,
            pressed = SpriteManager.GameSprite.MENU_PRESS.textureData.texture,
        )).apply {
            setBoundsFigmaY(MENU_X, MENU_Y, MENU_W, MENU_H)
            setOnClickListener { menuHandler() }
        }
        addActor(button)
    }

    private fun AdvancedStage.addCollection(){
        val button = ButtonClickable(ButtonClickable.Style(
            default = SpriteManager.GameSprite.COLLECTION_DEF.textureData.texture,
            pressed = SpriteManager.GameSprite.COLLECTION_PRESS.textureData.texture,
        )).apply {
            setBoundsFigmaY(COLLECTION_X, COLLECTION_Y, COLLECTION_W, COLLECTION_H)
            setOnClickListener { collectionHandler() }
        }
        addActor(button)
    }

    private fun AdvancedStage.addSlotGroup(){
        addActor(slotGroup)
    }

    private fun AdvancedStage.addSpin(){
        val button = ButtonClickable(ButtonClickable.Style(
            default = SpriteManager.GameSprite.SPIN_DEF.textureData.texture,
            pressed = SpriteManager.GameSprite.SPIN_PRESS.textureData.texture,
        )).apply {
            setBoundsFigmaY(SPIN_X, SPIN_Y, SPIN_W, SPIN_H)
            setOnClickListener { spinHandler() }
        }
        addActor(button)
    }



    private fun ButtonClickable.menuHandler() {
        NavigationUtil.back()
    }

    private fun ButtonClickable.collectionHandler() {
        NavigationUtil.navigate(CollectionScreen(), GameScreen())
    }

    private fun ButtonClickable.spinHandler() {
        coroutineBalance.launch { DataStoreUtil.updatePrice { it - 1000 } }
        disable()
        pressed()
        coroutineSpin.launch {
            slotGroup.spin().onEach { slotItem -> coroutineBalance.launch { DataStoreUtil.updatePrice { it + slotItem.price } } }
            enable()
            unpressed()
        }
    }

}