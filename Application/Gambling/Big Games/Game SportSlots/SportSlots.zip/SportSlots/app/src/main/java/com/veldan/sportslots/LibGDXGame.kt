package com.veldan.sportslots

import com.badlogic.gdx.Game
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.assets.AssetManager
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.glutils.ShapeRenderer
import com.badlogic.gdx.utils.ScreenUtils
import com.veldan.sportslots.assets.FontManager
import com.veldan.sportslots.assets.SpriteManager
import com.veldan.sportslots.screens.MenuScreen
import com.veldan.sportslots.utils.NavigationUtil
import com.veldan.sportslots.utils.Once

lateinit var game: LibGDXGame private set
lateinit var assetManager: AssetManager

class LibGDXGame : Game() {

    private val onceLoadAssets = Once()

    private val color = Color(2f / 255, 0f, 84f / 255, 1f)



    override fun create() {
        game = this
        assetManager = AssetManager()
        loadAssets()
    }

    override fun render() {
        ScreenUtils.clear(color)

        if (assetManager.update()) {
            onceLoadAssets.once {
                initAssets()
                NavigationUtil.navigate(MenuScreen())
            }
            super.render()
        }
    }

    override fun dispose() {
        super.dispose()
        assetManager.dispose()
    }



    private fun loadAssets() {
        SpriteManager.loadAll(assetManager)
        FontManager.loadAll(assetManager)
    }

    private fun initAssets() {
       SpriteManager.init(assetManager)
       FontManager.initAll(assetManager)
    }

}