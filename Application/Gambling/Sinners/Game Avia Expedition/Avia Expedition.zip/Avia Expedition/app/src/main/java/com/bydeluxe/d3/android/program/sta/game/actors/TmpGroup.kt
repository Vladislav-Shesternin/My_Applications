package com.bydeluxe.d3.android.program.sta.game.actors

import com.bydeluxe.d3.android.program.sta.game.utils.advanced.AdvancedGroup
import com.bydeluxe.d3.android.program.sta.game.utils.advanced.AdvancedScreen

class TmpGroup(override val screen: AdvancedScreen): AdvancedGroup() {

    override fun addActorsOnGroup() {

    }

}