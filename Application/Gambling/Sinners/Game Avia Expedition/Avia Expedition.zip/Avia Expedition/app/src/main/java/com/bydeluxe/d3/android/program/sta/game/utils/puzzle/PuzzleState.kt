package com.bydeluxe.d3.android.program.sta.game.utils.puzzle

enum class PuzzleState {
    ASSEMBLED, NOT_ASSEMBLED
}