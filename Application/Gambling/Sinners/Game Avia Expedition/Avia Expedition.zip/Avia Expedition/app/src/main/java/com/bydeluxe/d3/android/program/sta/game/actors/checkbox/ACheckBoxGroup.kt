package com.bydeluxe.d3.android.program.sta.game.actors.checkbox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}