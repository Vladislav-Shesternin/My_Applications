package com.bydeluxe.d3.android.program.sta.game.utils

const val WIDTH_UI     = 648f
const val HEIGHT_UI    = 1403f

const val TIME_ANIM = 0.3f